import React, { useRef, useEffect, useState, useCallback } from 'react';
import * as THREE from 'three';
import { useSceneStore } from '../../store/sceneStore';
import { useLightsStore } from '../../store/lightsStore';
import { ThreeSceneProvider } from '../../hooks/useThreeScene';
import { SceneManager, RenderPipeline, LightManager, ModelLoader } from '../../three/engine';
import { ViewportToolbar } from './ViewportToolbar';
import { CameraBookmarks } from './CameraBookmarks';

interface ViewportProps {
  sceneManagerRef: React.MutableRefObject<SceneManager | null>;
  onScreenshot: (dataUrl: string) => void;
}

export const Viewport: React.FC<ViewportProps> = ({ sceneManagerRef, onScreenshot }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const resizeObserverRef = useRef<ResizeObserver | null>(null);
  const renderPipelineRef = useRef<RenderPipeline | null>(null);
  const lightManagerRef = useRef<LightManager | null>(null);
  const modelLoaderRef = useRef<ModelLoader | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [loadProgress, setLoadProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Store selectors
  const showGrid = useSceneStore((s) => s.showGrid);
  const turntable = useSceneStore((s) => s.turntable);
  const environment = useSceneStore((s) => s.environment);
  const renderSettings = useSceneStore((s) => s.renderSettings);
  const setModel = useSceneStore((s) => s.setModel);

  const lights = useLightsStore((s) => s.lights);

  // Initialize the 3D scene on mount
  useEffect(() => {
    if (!containerRef.current) return;

    const sceneManager = new SceneManager();
    sceneManagerRef.current = sceneManager;
    sceneManager.attach(containerRef.current);

    const lightManager = new LightManager(sceneManager.scene);
    lightManagerRef.current = lightManager;

    const modelLoader = new ModelLoader(sceneManager.scene);
    modelLoaderRef.current = modelLoader;

    modelLoader.setCallbacks({
      onProgress: (p) => setLoadProgress(p),
      onLoaded: (name) => {
        setIsLoading(false);
        setLoadProgress(100);
        setModel('', name);
        setTimeout(() => setLoadProgress(0), 1000);
      },
      onError: (err) => {
        setIsLoading(false);
        setLoadProgress(0);
        setLoadError(err);
        setTimeout(() => setLoadError(null), 4000);
      },
    });

    sceneManager.setGrid(true);

    const renderPipeline = new RenderPipeline(sceneManager);
    renderPipelineRef.current = renderPipeline;
    renderPipeline.build();

    // Run our own render loop that uses the EffectComposer.
    // We do NOT call sceneManager.startRenderLoop() because that
    // calls renderer.render directly — we need to go through the composer.
    const clock = new THREE.Clock();
    const loop = () => {
      const delta = clock.getDelta();
      // Turntable
      if (sceneManager._turntableActive) {
        const model = sceneManager._findModel();
        if (model) model.rotation.y += delta * sceneManager._turntableSpeed * 0.5;
      }
      sceneManager.controls.update();
      renderPipeline.render();
      sceneManager._animationId = requestAnimationFrame(loop);
    };
    sceneManager._animationId = requestAnimationFrame(loop);

    // Set up resize observer
    const observer = new ResizeObserver(() => {
      sceneManager.resize();
      renderPipeline.resize();
    });
    observer.observe(containerRef.current);
    resizeObserverRef.current = observer;

    return () => {
      observer.disconnect();
      sceneManager.stopRenderLoop();
      renderPipeline.dispose();
      modelLoader.dispose();
      lightManager.dispose();
      sceneManager.dispose();
      sceneManagerRef.current = null;
      renderPipelineRef.current = null;
      lightManagerRef.current = null;
      modelLoaderRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sync grid visibility
  useEffect(() => {
    sceneManagerRef.current?.setGrid(showGrid);
  }, [showGrid, sceneManagerRef]);

  // Sync environment background
  useEffect(() => {
    sceneManagerRef.current?.setBackground(environment.background, environment.showBackground);
  }, [environment.background, environment.showBackground, sceneManagerRef]);

  // Sync render settings
  useEffect(() => {
    const rp = renderPipelineRef.current;
    if (!rp) return;
    rp.setEngine(renderSettings.engine);
    rp.setToneMapping(renderSettings.tonemapping);
    rp.setExposure(renderSettings.exposure);
    rp.setQuality(renderSettings.quality);
    rp.setShadowQuality(renderSettings.shadowQuality);
    rp.setBloom(
      renderSettings.bloom.enabled,
      renderSettings.bloom.intensity,
      renderSettings.bloom.threshold,
      renderSettings.bloom.radius
    );
    rp.setAO(
      renderSettings.ao.enabled,
      renderSettings.ao.radius,
      renderSettings.ao.intensity
    );
    rp.setAntialiasing(renderSettings.antialiasing);
    rp.setVignette(
      renderSettings.vignette.enabled,
      renderSettings.vignette.intensity
    );
    rp.setColorGrading(
      renderSettings.colorGrading.enabled,
      renderSettings.colorGrading.brightness,
      renderSettings.colorGrading.contrast,
      renderSettings.colorGrading.saturation
    );
  }, [renderSettings, renderPipelineRef]);

  // Sync lights to scene
  useEffect(() => {
    lightManagerRef.current?.syncLights(
      lights.map((l) => ({
        id: l.id,
        type: l.type,
        color: l.color,
        brightness: l.brightness,
        opacity: l.opacity,
        visible: l.visible,
        solo: l.solo,
        falloff: l.falloff,
        gearVisible: l.gearVisible,
        transform: l.transform,
        spotAngle: l.type === 'spot' ? 45 : l.type === 'rim' ? 30 : undefined,
        spotPenumbra: l.type === 'spot' ? 0.5 : l.type === 'rim' ? 0.3 : undefined,
        spotDecay: 2,
        areaWidth: l.type === 'overhead' ? 4 : l.type === 'area' ? 2 : undefined,
        areaHeight: l.type === 'overhead' ? 4 : l.type === 'area' ? 2 : undefined,
      }))
    );
  }, [lights, lightManagerRef]);

  // Sync turntable state to SceneManager
  useEffect(() => {
    const sm = sceneManagerRef.current;
    if (!sm) return;
    sm._turntableActive = turntable.active;
    sm._turntableSpeed = turntable.speed;
  }, [turntable.active, turntable.speed, sceneManagerRef]);

  // Drag and drop handlers
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.currentTarget === e.target) {
      setIsDragging(false);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'copy';
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(false);

      const files = e.dataTransfer.files;
      if (files.length === 0) return;

      const file = files[0];
      const ext = file.name.toLowerCase().split('.').pop();
      if (ext === 'glb' || ext === 'gltf') {
        loadModelFile(file);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [modelLoaderRef]
  );

  // Load model from file
  const loadModelFile = useCallback(
    (file: File) => {
      if (!modelLoaderRef.current) return;
      setIsLoading(true);
      setLoadError(null);
      setLoadProgress(0);
      modelLoaderRef.current.loadFromFile(file);
    },
    [modelLoaderRef]
  );

  // File picker
  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) loadModelFile(file);
      e.target.value = '';
    },
    [loadModelFile]
  );

  const handleOpenFilePicker = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  // Screenshot handler
  const handleScreenshot = useCallback(() => {
    const dataUrl = renderPipelineRef.current
      ? renderPipelineRef.current.capture()
      : sceneManagerRef.current?.takeScreenshot() ?? '';
    if (dataUrl) onScreenshot(dataUrl);
  }, [sceneManagerRef, renderPipelineRef, onScreenshot]);

  return (
    <ThreeSceneProvider>
      <div style={{ display: 'flex', flexDirection: 'column', width: '100%', height: '100%' }}>
        <ViewportToolbar
          sceneManagerRef={sceneManagerRef}
          onScreenshot={handleScreenshot}
          onLoadModel={handleOpenFilePicker}
        />
        <div
          ref={containerRef}
          style={{
            position: 'relative',
            flex: 1,
            overflow: 'hidden',
            background: 'var(--bg-deep)',
          }}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          {isDragging && (
            <div className="drop-overlay">
              <span>Drop .glb file to load model</span>
            </div>
          )}

          {isLoading && loadProgress < 100 && (
            <div
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                zIndex: 10,
                padding: '6px 12px',
              }}
            >
              <div className="progress-bar">
                <div
                  className="progress-bar-fill"
                  style={{ width: `${loadProgress}%` }}
                />
              </div>
            </div>
          )}

          {loadError && (
            <div
              style={{
                position: 'absolute',
                bottom: 12,
                left: '50%',
                transform: 'translateX(-50%)',
                zIndex: 10,
                background: 'var(--danger)',
                color: '#fff',
                padding: '4px 12px',
                borderRadius: 'var(--radius-sm)',
                fontSize: 11,
              }}
            >
              {loadError}
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept=".glb,.gltf"
            style={{ display: 'none' }}
            onChange={handleFileInput}
          />

          <CameraBookmarks sceneManagerRef={sceneManagerRef} />
        </div>
      </div>
    </ThreeSceneProvider>
  );
};