import React, { useEffect, useRef, useCallback, useState } from 'react';
import { useUIStore } from '../../store/uiStore';
import { useSceneStore } from '../../store/sceneStore';
import { useLightsStore } from '../../store/lightsStore';
import type { SceneManager } from '../../three/engine';

interface MenuItem {
  label: string;
  shortcut?: string;
  action?: () => void;
  separator?: boolean;
  submenu?: MenuDefinition;
}

interface MenuDefinition {
  [key: string]: MenuItem;
}

const MENU_DEFINITIONS: Record<string, MenuDefinition> = {
  Project: {
    new: { label: 'New', action: () => {} },
    open: { label: 'Open', shortcut: 'Ctrl+O', action: () => {} },
    save: { label: 'Save', shortcut: 'Ctrl+S', action: () => {} },
    saveAs: { label: 'Save As', action: () => {} },
    sep1: { label: '', separator: true },
    recent: { label: 'Recent Files', submenu: { r1: { label: 'No recent files', action: () => {} } } },
    sep2: { label: '', separator: true },
    exit: { label: 'Exit', action: () => {} },
  },
  Edit: {
    undo: { label: 'Undo', shortcut: 'Ctrl+Z', action: () => {} },
    redo: { label: 'Redo', shortcut: 'Ctrl+Y', action: () => {} },
    sep1: { label: '', separator: true },
    copyLight: { label: 'Copy Light', action: () => { const s = useLightsStore.getState(); if (s.selectedLightId) s.duplicateLight(s.selectedLightId); } },
    pasteLight: { label: 'Paste Light', action: () => {} },
  },
  Create: {
    pointLight: { label: 'Point Light', action: () => useLightsStore.getState().addLight('point') },
    spotLight: { label: 'Spot Light', action: () => useLightsStore.getState().addLight('spot') },
    areaLight: { label: 'Area Light', action: () => useLightsStore.getState().addLight('area') },
    directionalLight: { label: 'Directional Light', action: () => useLightsStore.getState().addLight('directional') },
    iesLight: { label: 'IES Light', action: () => useLightsStore.getState().addLight('ies') },
    overheadLight: { label: 'Overhead Light', action: () => useLightsStore.getState().addLight('overhead') },
    underlight: { label: 'Under Light', action: () => useLightsStore.getState().addLight('underlight') },
    rimLight: { label: 'Rim Light', action: () => useLightsStore.getState().addLight('rim') },
    fillLight: { label: 'Fill Light', action: () => useLightsStore.getState().addLight('fill') },
    sep1: { label: '', separator: true },
    addCamera: { label: 'Add Camera', action: () => {} },
    addEnvironment: { label: 'Add Environment', action: () => {} },
  },
  Canvas: {
    resetView: { label: 'Reset View', shortcut: 'F', action: () => {} },
    frameAll: { label: 'Frame All', action: () => {} },
    sep1: { label: '', separator: true },
    toggleGrid: { label: 'Toggle Grid', action: () => useSceneStore.getState().toggleGrid() },
    toggleBackground: { label: 'Toggle Background', action: () => useSceneStore.getState().toggleBackground() },
  },
  Window: {
    defaultLayout: { label: 'Default Layout', action: () => useUIStore.getState().setPanelLayout('default') },
    lightingOnly: { label: 'Lighting Only', action: () => useUIStore.getState().setPanelLayout('lighting') },
    fullPreview: { label: 'Full Preview', action: () => useUIStore.getState().setPanelLayout('fullPreview') },
  },
  Help: {
    docs: { label: 'Documentation', action: () => window.open('https://docs.lightstudio.dev', '_blank') },
    shortcuts: { label: 'Keyboard Shortcuts', action: () => {} },
    sep1: { label: '', separator: true },
    about: { label: 'About', action: () => useUIStore.getState().setAboutModal(true) },
  },
};

const MENU_KEYS = ['Project', 'Edit', 'Create', 'Canvas', 'Window', 'Help'];

interface TopMenubarProps {
  sceneManagerRef?: React.MutableRefObject<SceneManager | null>;
}

export const TopMenubar: React.FC<TopMenubarProps> = () => {
  const openMenu = useUIStore((s) => s.openMenu);
  const setOpenMenu = useUIStore((s) => s.setOpenMenu);
  const [hoveredMenu, setHoveredMenu] = useState<string | null>(null);
  const menuBarRef = useRef<HTMLDivElement>(null);

  // Close menu on outside click
  useEffect(() => {
    if (!openMenu) return;
    const handler = (e: MouseEvent) => {
      if (menuBarRef.current && !menuBarRef.current.contains(e.target as Node)) {
        setOpenMenu(null);
        setHoveredMenu(null);
      }
    };
    // Delay to avoid the same click closing immediately
    const timer = setTimeout(() => {
      document.addEventListener('mousedown', handler);
    }, 0);
    return () => {
      clearTimeout(timer);
      document.removeEventListener('mousedown', handler);
    };
  }, [openMenu, setOpenMenu]);

  const handleMenuClick = useCallback(
    (menuKey: string) => {
      if (openMenu === menuKey) {
        setOpenMenu(null);
        setHoveredMenu(null);
      } else {
        setOpenMenu(menuKey);
        setHoveredMenu(null);
      }
    },
    [openMenu, setOpenMenu]
  );

  const handleMenuHover = useCallback(
    (menuKey: string) => {
      if (openMenu) {
        setOpenMenu(menuKey);
        setHoveredMenu(menuKey);
      }
    },
    [openMenu, setOpenMenu]
  );

  const handleItemClick = useCallback(
    (item: MenuItem) => {
      item.action?.();
      setOpenMenu(null);
      setHoveredMenu(null);
    },
    [setOpenMenu]
  );

  return (
    <div
      ref={menuBarRef}
      style={{
        display: 'flex',
        alignItems: 'center',
        height: 28,
        background: 'var(--bg-deep)',
        borderBottom: '1px solid var(--border)',
        flexShrink: 0,
        zIndex: 100,
        position: 'relative',
      }}
    >
      {MENU_KEYS.map((key) => (
        <div key={key} style={{ position: 'relative' }}>
          <button
            onClick={() => handleMenuClick(key)}
            onMouseEnter={() => handleMenuHover(key)}
            style={{
              padding: '0 10px',
              height: '100%',
              fontSize: 11,
              color: openMenu === key ? 'var(--text)' : 'var(--text-sec)',
              background: openMenu === key ? 'var(--bg-card)' : 'transparent',
              border: 'none',
              cursor: 'pointer',
              transition: 'all 0.1s',
              fontFamily: 'inherit',
            }}
          >
            {key}
          </button>

          {/* Dropdown */}
          {openMenu === key && MENU_DEFINITIONS[key] && (
            <div
              className="context-menu"
              style={{
                position: 'absolute',
                top: '100%',
                left: 0,
                marginTop: -1,
              }}
            >
              {Object.values(MENU_DEFINITIONS[key]).map((item, idx) => {
                if (item.separator) {
                  return <div key={`sep-${idx}`} className="context-menu-sep" />;
                }

                const hasSubmenu = item.submenu && Object.keys(item.submenu).length > 0;

                return (
                  <div
                    key={`${key}-${idx}`}
                    style={{ position: 'relative' }}
                    onMouseEnter={() => hasSubmenu && setHoveredMenu(`${key}-${idx}`)}
                    onMouseLeave={() => setHoveredMenu(null)}
                  >
                    <div
                      className="context-menu-item"
                      onClick={() => !hasSubmenu && handleItemClick(item)}
                      style={{
                        justifyContent: hasSubmenu ? 'space-between' : undefined,
                        paddingRight: hasSubmenu ? 20 : 10,
                      }}
                    >
                      <span>{item.label}</span>
                      <span style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        {item.shortcut && (
                          <span style={{ fontSize: 10, color: 'var(--text-dim)', marginLeft: 16 }}>
                            {item.shortcut}
                          </span>
                        )}
                        {hasSubmenu && (
                          <svg width="8" height="8" viewBox="0 0 8 8" fill="var(--text-dim)">
                            <path d="M2 0l6 4-6 4z" />
                          </svg>
                        )}
                      </span>
                    </div>

                    {/* Submenu */}
                    {hasSubmenu && hoveredMenu === `${key}-${idx}` && (
                      <div
                        className="context-menu"
                        style={{
                          position: 'absolute',
                          top: -1,
                          left: '100%',
                        }}
                      >
                        {Object.values(item.submenu!).map((subItem, subIdx) => (
                          <div
                            key={`${key}-sub-${subIdx}`}
                            className="context-menu-item"
                            onClick={() => handleItemClick(subItem)}
                          >
                            {subItem.label}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};