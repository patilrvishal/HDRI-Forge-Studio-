import React, { useRef, useState, useCallback, useEffect } from 'react';
import { TopMenubar } from '../Toolbar/TopMenubar';
import { LeftToolbar } from '../Toolbar/LeftToolbar';
import { Viewport } from '../Viewport/Viewport';
import { LightListPanel } from '../Lights/LightListPanel';
import { LightProperties } from '../Lights/LightProperties';
import { PresetBrowser } from '../Presets/PresetBrowser';
import { LightPreview } from '../Previews/LightPreview';
import { MaterialPreviewTab, getMaterialPreviewThumbnail } from '../Previews/MaterialPreviewTab';
import { useUIStore } from '../../store/uiStore';
import { useSceneStore } from '../../store/sceneStore';
import { useLightsStore } from '../../store/lightsStore';
import { usePresetsStore } from '../../store/presetsStore';
import { useKeyboardShortcuts } from '../../hooks/useKeyboardShortcuts';
import { SceneManager } from '../../three/engine';
import * as THREE from 'three';

const LEFT_PANEL_WIDTH = 220;
const RIGHT_PANEL_WIDTH = 320;
const BOTTOM_PANEL_HEIGHT = 240;


export const AppLayout: React.FC = () => {
  const sceneManagerRef = useRef<SceneManager | null>(null);
  const envMapRef = useRef<THREE.Texture | null>(null);

  const leftPanelOpen = useUIStore((s) => s.leftPanelOpen);
  const rightPanelOpen = useUIStore((s) => s.rightPanelOpen);
  const bottomPanelOpen = useUIStore((s) => s.bottomPanelOpen);
  const settingsModalOpen = useUIStore((s) => s.settingsModalOpen);
  const aboutModalOpen = useUIStore((s) => s.aboutModalOpen);
  const setSettingsModal = useUIStore((s) => s.setSettingsModal);
  const setAboutModal = useUIStore((s) => s.setAboutModal);
  const setActiveTool = useUIStore((s) => s.setActiveTool);
  const toggleFullscreen = useUIStore((s) => s.toggleFullscreen);
  const toggleTurntable = useSceneStore((s) => s.toggleTurntable);

  const [rightTab, setRightTab] = useState<'properties' | 'preview' | 'material'>('properties');
  const [, setScreenshotUrl] = useState<string | null>(null);

  // Generate studio env map on mount for material preview
  useEffect(() => {
    // Create a simple environment using PMREMGenerator from the scene manager
    // This will be passed to MaterialPreview for PBR reflections
    const createEnvForPreview = async () => {
      // We'll set the env map when the scene manager is ready
      // For now, the MaterialPreview works without it (uses lights only)
    };
    createEnvForPreview().catch(() => {});
  }, []);

  // Thumbnail generator callback for PresetBrowser
  const handleGenerateThumbnail = useCallback((lights: Parameters<typeof getMaterialPreviewThumbnail>[0]) => {
    return getMaterialPreviewThumbnail(lights);
  }, []);

  // Screenshot handler
  const handleScreenshot = useCallback((dataUrl: string) => {
    setScreenshotUrl(dataUrl);
    const link = document.createElement('a');
    link.download = `lightstudio-${Date.now()}.png`;
    link.href = dataUrl;
    link.click();
  }, []);

  // Keyboard shortcuts
  useKeyboardShortcuts({
    onSave: () => {
      // Save scene to localStorage
      const sceneState = useSceneStore.getState();
      const lightsState = useLightsStore.getState();
      const data = {
        scene: {
          modelName: sceneState.modelName,
          camera: sceneState.camera,
          environment: sceneState.environment,
          renderSettings: sceneState.renderSettings,
          showGrid: sceneState.showGrid,
          turntable: sceneState.turntable,
          cameraBookmarks: sceneState.cameraBookmarks,
        },
        lights: lightsState.lights,
      };
      localStorage.setItem('lightstudio_save', JSON.stringify(data));
    },
    onOpen: () => {
      const raw = localStorage.getItem('lightstudio_save');
      if (!raw) return;
      try {
        const data = JSON.parse(raw);
        if (data.scene) {
          useSceneStore.getState().loadSceneState(data.scene);
        }
        if (data.lights) {
          useLightsStore.getState().setLightsFromPreset(data.lights);
        }
      } catch {
        // ignore parse errors
      }
    },
    onUndo: () => {},
    onRedo: () => {},
    onDelete: () => {
      const id = useLightsStore.getState().selectedLightId;
      if (id) useLightsStore.getState().removeLight(id);
    },
    setActiveTool,
    onFrameAll: () => {
      sceneManagerRef.current?.animateCameraTo([5, 3, 5], [0, 0.5, 0], 500);
    },
    toggleIsolate: () => setActiveTool('isolate'),
    toggleVisibility: () => {
      const id = useLightsStore.getState().selectedLightId;
      if (id) useLightsStore.getState().toggleLightVisibility(id);
    },
    toggleTurntable,
    toggleFullscreen,
    setViewMode: (mode: string) => {
      const presets: Record<string, [number, number, number]> = {
        front: [0, 1.5, 8],
        right: [8, 1.5, 0],
        top: [0, 8, 0.01],
        perspective: [5, 3, 5],
      };
      const target: [number, number, number] = mode === 'top' ? [0, 0, 0] : [0, 0.5, 0];
      const pos = presets[mode];
      if (pos) {
        sceneManagerRef.current?.animateCameraTo(pos, target, 500);
      }
    },
  });

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        width: '100%',
        height: '100%',
        background: 'var(--bg-deep)',
        overflow: 'hidden',
      }}
    >
      {/* Top Menu Bar */}
      <TopMenubar sceneManagerRef={sceneManagerRef} />

      {/* Main body */}
      <div
        style={{
          display: 'flex',
          flex: 1,
          overflow: 'hidden',
          minHeight: 0,
        }}
      >
        {/* Left Toolbar */}
        <LeftToolbar sceneManagerRef={sceneManagerRef} />

        {/* Left Panel — Light List */}
        {leftPanelOpen && (
          <div
            className="panel"
            style={{
              width: LEFT_PANEL_WIDTH,
              borderRight: '1px solid var(--border)',
              flexShrink: 0,
              overflow: 'hidden',
            }}
          >
            <div className="panel-header">
              <h3>
                <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor" style={{ opacity: 0.6 }}>
                  <circle cx="5" cy="5" r="3" />
                </svg>
                Light List
              </h3>
              <button
                className="btn-icon"
                style={{ width: 20, height: 20 }}
                onClick={() => useLightsStore.getState().addLight()}
                title="Add Light"
                aria-label="Add Light"
              >
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M6 1v10M1 6h10" />
                </svg>
              </button>
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              <LightListPanel />
            </div>
          </div>
        )}

        {/* Center: Viewport + Bottom panels */}
        <div
          style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            minWidth: 0,
          }}
        >
          {/* Viewport area */}
          <div
            style={{
              flex: bottomPanelOpen ? 1 : 1,
              overflow: 'hidden',
              minWidth: 0,
              minHeight: 0,
            }}
          >
            <Viewport sceneManagerRef={sceneManagerRef} onScreenshot={handleScreenshot} />
          </div>

          {/* Bottom panels */}
          {bottomPanelOpen && (
            <div
              style={{
                height: BOTTOM_PANEL_HEIGHT,
                display: 'flex',
                borderTop: '1px solid var(--border)',
                flexShrink: 0,
              }}
            >
              {/* Bottom left: Timeline (Phase 5) */}
              <div
                className="panel"
                style={{
                  flex: 1,
                  borderRight: '1px solid var(--border)',
                }}
              >
                <div className="panel-header">
                  <h3>Timeline</h3>
                </div>
                <div className="panel-body">
                  <div className="placeholder-panel">
                    <span>Timeline — Built in Phase 5</span>
                  </div>
                </div>
              </div>

              {/* Bottom right: Preset Browser (Phase 3) */}
              <div
                className="panel"
                style={{
                  width: 300,
                  flexShrink: 0,
                }}
              >
                <div className="panel-header">
                  <h3>Presets</h3>
                </div>
                <PresetBrowser onGenerateThumbnail={handleGenerateThumbnail} />
              </div>
            </div>
          )}
        </div>

        {/* Right Panel */}
        {rightPanelOpen && (
          <div
            className="panel"
            style={{
              width: RIGHT_PANEL_WIDTH,
              borderLeft: '1px solid var(--border)',
              flexShrink: 0,
              overflow: 'hidden',
            }}
          >
            {/* Tab bar */}
            <div style={{ borderBottom: '1px solid var(--border)' }}>
              <div className="tab-bar">
                <div
                  className={`tab-item ${rightTab === 'properties' ? 'active' : ''}`}
                  onClick={() => setRightTab('properties')}
                >
                  Properties
                </div>
                <div
                  className={`tab-item ${rightTab === 'preview' ? 'active' : ''}`}
                  onClick={() => setRightTab('preview')}
                >
                  Light Prev
                </div>
                <div
                  className={`tab-item ${rightTab === 'material' ? 'active' : ''}`}
                  onClick={() => setRightTab('material')}
                >
                  Material
                </div>
              </div>
            </div>

            {/* Tab content */}
            <div className="panel-body" style={{ overflow: 'hidden', padding: 0, display: 'flex', flexDirection: 'column' }}>
              {rightTab === 'properties' && (
                <div style={{ flex: 1, overflowY: 'auto' }}>
                  <LightProperties />
                </div>
              )}
              {rightTab === 'preview' && (
                <div style={{ flex: 1, overflow: 'hidden' }}>
                  <LightPreview />
                </div>
              )}
              {rightTab === 'material' && (
                <div style={{ flex: 1, overflow: 'hidden' }}>
                  <MaterialPreviewTab envMap={envMapRef.current} />
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Settings Modal */}
      {settingsModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 9999,
          }}
          onClick={() => setSettingsModal(false)}
        >
          <div
            className="context-menu"
            style={{
              minWidth: 300,
              padding: 12,
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <span style={{ fontSize: 13, fontWeight: 600 }}>Settings</span>
              <button
                className="btn-icon"
                onClick={() => setSettingsModal(false)}
                aria-label="Close settings"
              >
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M1 1l10 10M11 1L1 11" />
                </svg>
              </button>
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-sec)' }}>
              Render settings will be available in Phase 4.
            </div>
          </div>
        </div>
      )}

      {/* About Modal */}
      {aboutModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 9999,
          }}
          onClick={() => setAboutModal(false)}
        >
          <div
            className="context-menu"
            style={{
              minWidth: 260,
              padding: 16,
              textAlign: 'center',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--accent)', marginBottom: 4 }}>
              LightStudio
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-sec)', marginBottom: 8 }}>
              3D Car Lighting Studio
            </div>
            <div style={{ fontSize: 10, color: 'var(--text-dim)' }}>
              Version 1.0.0 — Phase 3
            </div>
            <button
              className="btn-primary"
              style={{ marginTop: 12, padding: '4px 16px' }}
              onClick={() => setAboutModal(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};