import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';

let _rectAreaLibInitialized = false;
function ensureRectAreaLib(): void {
  if (!_rectAreaLibInitialized) {
    RectAreaLightUniformsLib.init();
    _rectAreaLibInitialized = true;
  }
}

export interface SceneInstances {
  sceneManager: SceneManager;
  renderPipeline: RenderPipeline;
  lightManager: LightManager;
  modelLoader: ModelLoader;
}

export class SceneManager {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  controls: OrbitControls;
  container: HTMLElement | null = null;
  ground: THREE.Mesh | null = null;
  grid: THREE.GridHelper | null = null;
  pmremGenerator: THREE.PMREMGenerator;
  private _animationId: number = 0;
  private _clock = new THREE.Clock();
  private _onFrame: ((delta: number) => void) | null = null;
  private _turntableActive = false;
  private _turntableSpeed = 1.0;

  constructor() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#0d0d1a');

    this.camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000);
    this.camera.position.set(5, 3, 5);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.minDistance = 1;
    this.controls.maxDistance = 50;
    this.controls.maxPolarAngle = Math.PI * 0.85;
    this.controls.target.set(0, 0.5, 0);
    this.controls.update();

    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.pmremGenerator.compileEquirectangularShader();

    // Ambient light
    const ambient = new THREE.AmbientLight(0x404060, 0.15);
    this.scene.add(ambient);
  }

  attach(container: HTMLElement): void {
    this.container = container;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';

    // Ground plane
    const groundGeo = new THREE.PlaneGeometry(40, 40);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x2a2a3e,
      metalness: 0.3,
      roughness: 0.7,
      envMapIntensity: 0.4,
    });
    this.ground = new THREE.Mesh(groundGeo, groundMat);
    this.ground.rotation.x = -Math.PI / 2;
    this.ground.position.y = -0.01;
    this.ground.receiveShadow = true;
    this.scene.add(this.ground);

    this.setGrid(true);
    this.resize();
  }

  detach(): void {
    if (this.container && this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
    this.container = null;
  }

  resize(): void {
    if (!this.container) return;
    const w = Math.max(2, this.container.clientWidth);
    const h = Math.max(2, this.container.clientHeight);
    if (w === 0 || h === 0) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  getContainerSize(): { width: number; height: number } {
    if (!this.container) return { width: 0, height: 0 };
    const dpr = this.renderer.getPixelRatio();
    return {
      width: Math.round(this.container.clientWidth * dpr),
      height: Math.round(this.container.clientHeight * dpr),
    };
  }

  setGrid(visible: boolean): void {
    if (visible && !this.grid) {
      this.grid = new THREE.GridHelper(20, 40, 0x444466, 0x2a2a44);
      this.grid.position.y = 0.005;
      this.scene.add(this.grid);
    } else if (!visible && this.grid) {
      this.scene.remove(this.grid);
      this.grid.geometry.dispose();
      (this.grid.material as THREE.Material).dispose();
      this.grid = null;
    }
    if (this.grid) this.grid.visible = visible;
  }

  setBackground(color: string, show: boolean): void {
    if (show) {
      this.scene.background = new THREE.Color(color);
    } else {
      this.scene.background = new THREE.Color('#0d0d1a');
    }
  }

  setTurntable(active: boolean, speed: number): void {
    this._turntableActive = active;
    this._turntableSpeed = speed;
  }

  animateCameraTo(
    position: [number, number, number],
    target: [number, number, number],
    duration: number = 600
  ): void {
    const startPos = this.camera.position.clone();
    const startTarget = this.controls.target.clone();
    const endPos = new THREE.Vector3(...position);
    const endTarget = new THREE.Vector3(...target);
    const startTime = performance.now();

    const animate = () => {
      const elapsed = performance.now() - startTime;
      const t = Math.min(elapsed / duration, 1);
      const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

      this.camera.position.lerpVectors(startPos, endPos, ease);
      this.controls.target.lerpVectors(startTarget, endTarget, ease);
      this.controls.update();

      if (t < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }

  setOnFrame(cb: (delta: number) => void): void {
    this._onFrame = cb;
  }

  startRenderLoop(): void {
    const loop = () => {
      this._animationId = requestAnimationFrame(loop);
      const delta = this._clock.getDelta();

      // Turntable rotation
      if (this._turntableActive) {
        const model = this._findModel();
        if (model) {
          model.rotation.y += delta * this._turntableSpeed * 0.5;
        }
      }

      if (this._onFrame) this._onFrame(delta);
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
    };
    loop();
  }

  private _findModel(): THREE.Object3D | null {
    for (const child of this.scene.children) {
      if (
        child.type === 'Group' &&
        !(child instanceof THREE.GridHelper) &&
        !child.userData.isHelper &&
        child !== this.ground
      ) {
        return child;
      }
    }
    return null;
  }

  stopRenderLoop(): void {
    cancelAnimationFrame(this._animationId);
  }

  getCameraState(): { position: [number, number, number]; target: [number, number, number]; fov: number } {
    const target = this.controls.target;
    return {
      position: [
        this.camera.position.x,
        this.camera.position.y,
        this.camera.position.z,
      ] as [number, number, number],
      target: [target.x, target.y, target.z] as [number, number, number],
      fov: this.camera.fov,
    };
  }

  setCameraState(position: [number, number, number], target: [number, number, number], fov?: number): void {
    this.camera.position.set(...position);
    this.controls.target.set(...target);
    this.controls.update();
    if (fov !== undefined) {
      this.camera.fov = fov;
      this.camera.updateProjectionMatrix();
    }
  }

  takeScreenshot(): string {
    this.renderer.render(this.scene, this.camera);
    return this.renderer.domElement.toDataURL('image/png');
  }

  dispose(): void {
    this.stopRenderLoop();
    this.detach();
    this.pmremGenerator.dispose();
    this.scene.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) {
          obj.material.forEach((m) => m.dispose());
        } else {
          obj.material.dispose();
        }
      }
    });
    this.controls.dispose();
    this.renderer.dispose();
  }
}

export class RenderPipeline {
  private _sceneManager: SceneManager;

  constructor(sceneManager: SceneManager) {
    this._sceneManager = sceneManager;
  }

  setEngine(engine: 'pbr' | 'pathtracer'): void {
    if (engine === 'pbr') {
      this._sceneManager.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    } else {
      this._sceneManager.renderer.toneMapping = THREE.NoToneMapping;
    }
  }

  setToneMapping(mapping: 'aces' | 'reinhard' | 'linear'): void {
    switch (mapping) {
      case 'aces':
        this._sceneManager.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        break;
      case 'reinhard':
        this._sceneManager.renderer.toneMapping = THREE.ReinhardToneMapping;
        break;
      case 'linear':
        this._sceneManager.renderer.toneMapping = THREE.LinearToneMapping;
        break;
    }
    this._sceneManager.renderer.toneMappingExposure = 1.0;
    this._sceneManager.scene.needsUpdate = true;
  }

  setBloom(enabled: boolean, intensity: number, _threshold: number, _radius: number): void {
    if (enabled) {
      this._sceneManager.renderer.toneMappingExposure = 1.0 + intensity * 0.5;
    } else {
      this._sceneManager.renderer.toneMappingExposure = 1.0;
    }
  }

  setAO(_enabled: boolean, _radius: number, _intensity: number): void {
    // Ambient occlusion pass — placeholder for Phase 6
  }

  setAntialiasing(_mode: 'none' | 'fxaa' | 'smaa' | 'taa'): void {
    // Post-processing AA — placeholder for Phase 6
  }

  setShadowQuality(quality: 'none' | 'low' | 'medium' | 'high'): void {
    const r = this._sceneManager.renderer;
    switch (quality) {
      case 'none':
        r.shadowMap.enabled = false;
        break;
      case 'low':
        r.shadowMap.enabled = true;
        r.shadowMap.type = THREE.BasicShadowMap;
        break;
      case 'medium':
        r.shadowMap.enabled = true;
        r.shadowMap.type = THREE.PCFShadowMap;
        break;
      case 'high':
        r.shadowMap.enabled = true;
        r.shadowMap.type = THREE.PCFSoftShadowMap;
        break;
    }
  }

  setQuality(quality: 'low' | 'medium' | 'high' | 'ultra'): void {
    const r = this._sceneManager.renderer;
    switch (quality) {
      case 'low':
        r.setPixelRatio(1);
        break;
      case 'medium':
        r.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
        break;
      case 'high':
        r.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        break;
      case 'ultra':
        r.setPixelRatio(window.devicePixelRatio);
        break;
    }
    this._sceneManager.resize();
  }
}

interface LightSyncEntry {
  id: string;
  type: string;
  color: string;
  brightness: number;
  opacity: number;
  visible: boolean;
  solo: boolean;
  falloff: string;
  gearVisible: boolean;
  transform: {
    position: { x: number; y: number; z: number };
    spherical: { lat: number; lng: number; radius: number; height: number };
    rotation: { x: number; y: number; z: number; enabled: boolean };
  };
  // Spotlight-specific
  spotAngle?: number;
  spotPenumbra?: number;
  spotDecay?: number;
  // Area light specific
  areaWidth?: number;
  areaHeight?: number;
}

interface LightObjectEntry {
  object: THREE.Object3D;
  lightType: string;
  target?: THREE.Object3D;
}

export class LightManager {
  private _scene: THREE.Scene;
  private _entries: Map<string, LightObjectEntry> = new Map();
  private _helpers: Map<string, THREE.Object3D> = new Map();
  private _types: Map<string, string> = new Map();

  constructor(scene: THREE.Scene) {
    this._scene = scene;
    ensureRectAreaLib();
  }

  syncLights(lights: LightSyncEntry[]): void {
    const activeIds = new Set(lights.map((l) => l.id));
    const hasSolo = lights.some((l) => l.solo);

    // Remove stale lights
    for (const [id] of this._entries) {
      if (!activeIds.has(id)) {
        this._removeLight(id);
      }
    }

    // Create or update each light
    for (const ld of lights) {
      const isEffectiveSolo = hasSolo ? ld.solo : true;
      const shouldShow = ld.visible && isEffectiveSolo;

      const existing = this._entries.get(ld.id);
      const currentType = this._types.get(ld.id);

      // If type changed, recreate the light
      if (existing && currentType !== ld.type) {
        this._removeLight(ld.id);
      }

      if (!this._entries.has(ld.id)) {
        this._createLight(ld);
      }

      this._updateLight(ld, shouldShow);
    }
  }

  private _createLight(ld: LightSyncEntry): void {
    ensureRectAreaLib();
    const lightObj = this._createLightByType(ld.type);

    // For spot/directional, add a target object
    let target: THREE.Object3D | undefined;
    if (lightObj instanceof THREE.SpotLight || lightObj instanceof THREE.DirectionalLight) {
      target = new THREE.Object3D();
      target.position.set(0, 0, 0);
      this._scene.add(target);
      lightObj.target = target;
    }

    this._scene.add(lightObj);
    this._entries.set(ld.id, { object: lightObj, lightType: ld.type, target });
    this._types.set(ld.id, ld.type);

    // Create helper
    const helper = this._createHelper(ld.type, lightObj);
    if (helper) {
      this._helpers.set(ld.id, helper);
      this._scene.add(helper);
    }
  }

  private _updateLight(ld: LightSyncEntry, shouldShow: boolean): void {
    const entry = this._entries.get(ld.id);
    if (!entry) return;

    const { object: lightObj } = entry;

    // Compute position from spherical
    const s = ld.transform.spherical;
    const latRad = (s.lat * Math.PI) / 180;
    const lngRad = (s.lng * Math.PI) / 180;
    const px = s.radius * Math.cos(latRad) * Math.cos(lngRad);
    const py = s.height;
    const pz = s.radius * Math.cos(latRad) * Math.sin(lngRad);

    lightObj.position.set(px, py, pz);
    lightObj.visible = shouldShow;

    // Apply rotation if enabled
    if (ld.transform.rotation.enabled) {
      lightObj.rotation.set(
        (ld.transform.rotation.x * Math.PI) / 180,
        (ld.transform.rotation.y * Math.PI) / 180,
        (ld.transform.rotation.z * Math.PI) / 180,
      );
    }

    if (lightObj instanceof THREE.Light) {
      lightObj.color.set(ld.color);
      // Map brightness 0-1000 to intensity 0-10
      lightObj.intensity = (ld.brightness / 1000) * 10;

      // Apply opacity (only meaningful via distance/decay for physically-based)
      // We scale intensity by opacity/100 to simulate dimming
      if (ld.opacity < 100) {
        lightObj.intensity *= ld.opacity / 100;
      }

      // Falloff
      if (lightObj instanceof THREE.PointLight || lightObj instanceof THREE.SpotLight) {
        switch (ld.falloff) {
          case 'linear':
            lightObj.decay = 1;
            break;
          case 'none':
            lightObj.decay = 0;
            break;
          case 'custom':
            lightObj.decay = 1.5;
            break;
          case 'quadratic':
          default:
            lightObj.decay = 2;
            break;
        }
      }

      // Spotlight-specific
      if (lightObj instanceof THREE.SpotLight) {
        if (ld.spotAngle !== undefined) {
          lightObj.angle = (ld.spotAngle * Math.PI) / 180;
        }
        if (ld.spotPenumbra !== undefined) {
          lightObj.penumbra = ld.spotPenumbra;
        }
        if (ld.spotDecay !== undefined) {
          lightObj.decay = ld.spotDecay;
        }
      }

      // Area light dimensions
      if (lightObj instanceof THREE.RectAreaLight) {
        if (ld.areaWidth !== undefined) lightObj.width = ld.areaWidth;
        if (ld.areaHeight !== undefined) lightObj.height = ld.areaHeight;
      }

      // Shadow config
      this._configureShadows(lightObj, ld.type);
    }

    // Update target to look at origin for spot/directional
    if (entry.target) {
      entry.target.position.set(0, 0, 0);
    }

    // Update helper
    const helper = this._helpers.get(ld.id);
    if (helper) {
      helper.visible = shouldShow && ld.gearVisible;
      helper.position.copy(lightObj.position);
      helper.rotation.copy(lightObj.rotation);
      if (helper instanceof THREE.Mesh && lightObj instanceof THREE.Light) {
        (helper.material as THREE.MeshBasicMaterial).color.copy(lightObj.color);
      }
    }
  }

  private _createLightByType(type: string): THREE.Object3D {
    const color = 0xffffff;
    const intensity = 1;
    switch (type) {
      case 'directional': {
        const dl = new THREE.DirectionalLight(color, intensity);
        dl.castShadow = true;
        dl.shadow.mapSize.set(2048, 2048);
        dl.shadow.camera.near = 0.5;
        dl.shadow.camera.far = 50;
        dl.shadow.camera.left = -10;
        dl.shadow.camera.right = 10;
        dl.shadow.camera.top = 10;
        dl.shadow.camera.bottom = -10;
        dl.shadow.bias = -0.001;
        return dl;
      }
      case 'spot': {
        const sl = new THREE.SpotLight(color, intensity, 50, Math.PI / 4, 0.5, 2);
        sl.castShadow = true;
        sl.shadow.mapSize.set(2048, 2048);
        sl.shadow.bias = -0.001;
        return sl;
      }
      case 'area': {
        ensureRectAreaLib();
        return new THREE.RectAreaLight(color, intensity, 2, 2);
      }
      case 'overhead': {
        ensureRectAreaLib();
        return new THREE.RectAreaLight(color, intensity, 4, 4);
      }
      case 'rim': {
        const sl = new THREE.SpotLight(color, intensity, 50, Math.PI / 6, 0.3, 2);
        sl.castShadow = true;
        sl.shadow.mapSize.set(2048, 2048);
        sl.shadow.bias = -0.001;
        return sl;
      }
      case 'underlight': {
        const pl = new THREE.PointLight(color, intensity, 50, 2);
        pl.castShadow = true;
        pl.shadow.mapSize.set(1024, 1024);
        return pl;
      }
      case 'ies':
      case 'point':
      default: {
        const pl = new THREE.PointLight(color, intensity, 50, 2);
        pl.castShadow = true;
        pl.shadow.mapSize.set(1024, 1024);
        return pl;
      }
    }
  }

  private _configureShadows(light: THREE.Light, _type: string): void {
    const shadowCapable = light instanceof THREE.SpotLight
      || light instanceof THREE.DirectionalLight
      || light instanceof THREE.PointLight;

    if (!shadowCapable || !light.shadow) return;

    light.castShadow = true;
    light.shadow.bias = -0.001;

    if (light instanceof THREE.DirectionalLight) {
      light.shadow.mapSize.set(2048, 2048);
      light.shadow.camera.near = 0.5;
      light.shadow.camera.far = 50;
      light.shadow.camera.left = -10;
      light.shadow.camera.right = 10;
      light.shadow.camera.top = 10;
      light.shadow.camera.bottom = -10;
    } else if (light instanceof THREE.SpotLight) {
      light.shadow.mapSize.set(2048, 2048);
      light.shadow.camera.near = 0.5;
      light.shadow.camera.far = 50;
    } else if (light instanceof THREE.PointLight) {
      light.shadow.mapSize.set(1024, 1024);
      light.shadow.camera.near = 0.1;
      light.shadow.camera.far = 50;
    }
  }

  private _createHelper(type: string, light: THREE.Light): THREE.Object3D | null {
    const isArea = type === 'area' || type === 'overhead';
    let geo: THREE.BufferGeometry;
    if (isArea) {
      geo = new THREE.PlaneGeometry(0.3, 0.3);
    } else if (type === 'directional') {
      // Use a slightly larger sphere for directional
      geo = new THREE.SphereGeometry(0.1, 12, 12);
    } else {
      geo = new THREE.SphereGeometry(0.06, 10, 10);
    }
    const mat = new THREE.MeshBasicMaterial({
      color: light.color,
      transparent: true,
      opacity: 0.7,
      depthTest: false,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.userData.isHelper = true;
    mesh.renderOrder = 999;
    return mesh;
  }

  private _removeLight(id: string): void {
    const entry = this._entries.get(id);
    if (!entry) return;

    const { object, target } = entry;

    // Dispose shadow maps
    if (object instanceof THREE.Light && object.shadow && object.shadow.map) {
      object.shadow.map.dispose();
    }

    this._scene.remove(object);
    this._disposeObject(object);
    if (target) {
      this._scene.remove(target);
    }

    this._entries.delete(id);
    this._types.delete(id);

    const helper = this._helpers.get(id);
    if (helper) {
      this._scene.remove(helper);
      this._disposeObject(helper);
      this._helpers.delete(id);
    }
  }

  private _disposeObject(obj: THREE.Object3D): void {
    obj.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.geometry.dispose();
        if (child.material instanceof THREE.Material) {
          child.material.dispose();
        }
      }
    });
  }

  getLightObject(id: string): THREE.Object3D | undefined {
    return this._entries.get(id)?.object;
  }

  getLightCount(): number {
    return this._entries.size;
  }

  dispose(): void {
    const ids = Array.from(this._entries.keys());
    for (const id of ids) {
      this._removeLight(id);
    }
  }
}

export class ModelLoader {
  private _scene: THREE.Scene;
  private _currentModel: THREE.Group | null = null;
  private _loader = new GLTFLoader();
  private _loading = false;
  private _progress = 0;
  private _onProgress: ((progress: number) => void) | null = null;
  private _onLoaded: ((name: string) => void) | null = null;
  private _onError: ((error: string) => void) | null = null;

  constructor(scene: THREE.Scene) {
    this._scene = scene;
  }

  get loading(): boolean { return this._loading; }
  get progress(): number { return this._progress; }

  setCallbacks(callbacks: {
    onProgress?: (progress: number) => void;
    onLoaded?: (name: string) => void;
    onError?: (error: string) => void;
  }): void {
    this._onProgress = callbacks.onProgress ?? null;
    this._onLoaded = callbacks.onLoaded ?? null;
    this._onError = callbacks.onError ?? null;
  }

  async loadFromFile(file: File): Promise<void> {
    if (this._loading) return;
    this._loading = true;
    this._progress = 0;
    this._onProgress?.(0);

    const url = URL.createObjectURL(file);

    try {
      const gltf = await new Promise<THREE.GLTF>((resolve, reject) => {
        this._loader.load(
          url,
          (result) => resolve(result),
          (event) => {
            if (event.lengthComputable) {
              this._progress = (event.loaded / event.total) * 100;
              this._onProgress?.(this._progress);
            }
          },
          (error) => reject(error)
        );
      });

      this.removeCurrentModel();

      this._currentModel = gltf.scene;
      this._scene.add(gltf.scene);

      // Enable shadows
      gltf.scene.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });

      // Center and scale
      const box = new THREE.Box3().setFromObject(gltf.scene);
      const center = box.getCenter(new THREE.Vector3());
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z);
      if (maxDim > 0) {
        const scale = 4 / maxDim;
        gltf.scene.scale.multiplyScalar(scale);
      }
      // Recompute after scaling
      const box2 = new THREE.Box3().setFromObject(gltf.scene);
      const center2 = box2.getCenter(new THREE.Vector3());
      gltf.scene.position.sub(center2);
      gltf.scene.position.y += box2.getSize(new THREE.Vector3()).y / 2;

      this._loading = false;
      this._progress = 100;
      this._onProgress?.(100);
      this._onLoaded?.(file.name.replace(/\.(glb|gltf)$/i, ''));
    } catch (err) {
      this._loading = false;
      this._progress = 0;
      const msg = err instanceof Error ? err.message : 'Failed to load model';
      this._onError?.(msg);
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  removeCurrentModel(): void {
    if (this._currentModel) {
      this._scene.remove(this._currentModel);
      this._currentModel.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          if (Array.isArray(child.material)) {
            child.material.forEach((m) => m.dispose());
          } else {
            child.material.dispose();
          }
        }
      });
      this._currentModel = null;
    }
  }

  dispose(): void {
    this.removeCurrentModel();
  }
}