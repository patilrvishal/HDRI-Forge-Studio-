import { useEffect } from 'react';
import type { ActiveTool } from '../store/uiStore';

interface KeyboardShortcutCallbacks {
  onSave?: () => void;
  onOpen?: () => void;
  onUndo?: () => void;
  onRedo?: () => void;
  onDelete?: () => void;
  setActiveTool?: (tool: ActiveTool) => void;
  onFrameAll?: () => void;
  toggleIsolate?: () => void;
  toggleVisibility?: () => void;
  toggleTurntable?: () => void;
  toggleFullscreen?: () => void;
  setViewMode?: (mode: string) => void;
}

export function useKeyboardShortcuts(callbacks: KeyboardShortcutCallbacks): void {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isInput =
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.tagName === 'SELECT' ||
        target.isContentEditable;

      // Ctrl/Cmd shortcuts
      if (e.ctrlKey || e.metaKey) {
        switch (e.key.toLowerCase()) {
          case 's':
            e.preventDefault();
            callbacks.onSave?.();
            return;
          case 'o':
            e.preventDefault();
            callbacks.onOpen?.();
            return;
          case 'z':
            e.preventDefault();
            callbacks.onUndo?.();
            return;
          case 'y':
            e.preventDefault();
            callbacks.onRedo?.();
            return;
        }
      }

      // Don't handle single keys when in an input field
      if (isInput) return;

      switch (e.key) {
        case 'Delete':
        case 'Backspace':
          callbacks.onDelete?.();
          break;
        case 'g':
          callbacks.setActiveTool?.('move');
          break;
        case 'r':
          callbacks.setActiveTool?.('rotate');
          break;
        case 's':
          callbacks.setActiveTool?.('select');
          break;
        case 'f':
          callbacks.onFrameAll?.();
          break;
        case 'i':
          callbacks.toggleIsolate?.();
          break;
        case 'h':
          callbacks.toggleVisibility?.();
          break;
        case ' ':
          e.preventDefault();
          callbacks.toggleTurntable?.();
          break;
        case 'F11':
          e.preventDefault();
          callbacks.toggleFullscreen?.();
          break;
        // Numpad view shortcuts
        case '1':
          if (e.code === 'Numpad1' || e.location === 3) {
            callbacks.setViewMode?.('front');
          }
          break;
        case '3':
          if (e.code === 'Numpad3' || e.location === 3) {
            callbacks.setViewMode?.('right');
          }
          break;
        case '7':
          if (e.code === 'Numpad7' || e.location === 3) {
            callbacks.setViewMode?.('top');
          }
          break;
        case '0':
          if (e.code === 'Numpad0' || e.location === 3) {
            callbacks.setViewMode?.('perspective');
          }
          break;
      }
    };

    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [callbacks]);
}