import { create } from 'zustand';
import type { SceneState, CameraBookmark } from '../types/Scene';
import { DEFAULT_SCENE_STATE, createDefaultCameraBookmark } from '../types/Scene';

interface SceneStore extends SceneState {
  // Camera bookmarks
  cameraBookmarks: CameraBookmark[];
  
  // Model
  setModel: (path: string, name: string) => void;
  clearModel: () => void;
  
  // Camera
  setCamera: (position: [number, number, number], target: [number, number, number], fov?: number) => void;
  
  // Environment
  setEnvironment: (env: Partial<SceneState['environment']>) => void;
  toggleBackground: () => void;
  
  // Render settings
  setRenderSettings: (settings: Partial<SceneState['renderSettings']>) => void;
  setBloom: (bloom: Partial<SceneState['renderSettings']['bloom']>) => void;
  setAO: (ao: Partial<SceneState['renderSettings']['ao']>) => void;
  
  // Grid & turntable
  toggleGrid: () => void;
  setTurntable: (active: boolean, speed?: number) => void;
  toggleTurntable: () => void;
  
  // Camera bookmarks
  saveCameraBookmark: (name: string, position: [number, number, number], target: [number, number, number], fov: number) => void;
  loadCameraBookmark: (id: string) => CameraBookmark | undefined;
  removeCameraBookmark: (id: string) => void;
  
  // Scene load
  loadSceneState: (state: Partial<SceneState>) => void;
  resetScene: () => void;
}

export const useSceneStore = create<SceneStore>((set, get) => ({
  ...DEFAULT_SCENE_STATE,
  cameraBookmarks: [],

  setModel: (path, name) => {
    set({ modelPath: path, modelName: name });
  },

  clearModel: () => {
    set({ modelPath: null, modelName: 'No Model Loaded' });
  },

  setCamera: (position, target, fov) => {
    set((state) => ({
      camera: {
        position,
        target,
        fov: fov ?? state.camera.fov,
      },
    }));
  },

  setEnvironment: (env) => {
    set((state) => ({
      environment: { ...state.environment, ...env },
    }));
  },

  toggleBackground: () => {
    set((state) => ({
      environment: { ...state.environment, showBackground: !state.environment.showBackground },
    }));
  },

  setRenderSettings: (settings) => {
    set((state) => ({
      renderSettings: { ...state.renderSettings, ...settings },
    }));
  },

  setBloom: (bloom) => {
    set((state) => ({
      renderSettings: {
        ...state.renderSettings,
        bloom: { ...state.renderSettings.bloom, ...bloom },
      },
    }));
  },

  setAO: (ao) => {
    set((state) => ({
      renderSettings: {
        ...state.renderSettings,
        ao: { ...state.renderSettings.ao, ...ao },
      },
    }));
  },

  toggleGrid: () => {
    set((state) => ({ showGrid: !state.showGrid }));
  },

  setTurntable: (active, speed) => {
    set((state) => ({
      turntable: {
        active,
        speed: speed ?? state.turntable.speed,
      },
    }));
  },

  toggleTurntable: () => {
    set((state) => ({
      turntable: { ...state.turntable, active: !state.turntable.active },
    }));
  },

  saveCameraBookmark: (name, position, target, fov) => {
    const state = get();
    if (state.cameraBookmarks.length >= 8) return;
    const bookmark = createDefaultCameraBookmark(state.cameraBookmarks.length);
    bookmark.name = name;
    bookmark.position = position;
    bookmark.target = target;
    bookmark.fov = fov;
    set((s) => ({
      cameraBookmarks: [...s.cameraBookmarks, bookmark],
    }));
  },

  loadCameraBookmark: (id) => {
    return get().cameraBookmarks.find((b) => b.id === id);
  },

  removeCameraBookmark: (id) => {
    set((state) => ({
      cameraBookmarks: state.cameraBookmarks.filter((b) => b.id !== id),
    }));
  },

  loadSceneState: (newState) => {
    set((state) => ({ ...state, ...newState }));
  },

  resetScene: () => {
    set({ ...DEFAULT_SCENE_STATE, cameraBookmarks: [] });
  },
}));