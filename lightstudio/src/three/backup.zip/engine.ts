﻿import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import { setRawModelData, clearRawModelData } from '../store/modelDataStore';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { SMAAPass } from 'three/addons/postprocessing/SMAAPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { SSAOPass } from 'three/addons/postprocessing/SSAOPass.js';
import { FXAAShader } from 'three/addons/shaders/FXAAShader.js';
import type { GroundSettings } from '../types/Scene';

let _rectAreaLibInitialized = false;
function ensureRectAreaLib(): void {
  if (!_rectAreaLibInitialized) {
    RectAreaLightUniformsLib.init();
    _rectAreaLibInitialized = true;
  }
}

export interface SceneInstances {
  sceneManager: SceneManager;
  renderPipeline: RenderPipeline;
  lightManager: LightManager;
  modelLoader: ModelLoader;
}

export class SceneManager {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  controls: OrbitControls;
  container: HTMLElement | null = null;
  ground: THREE.Mesh | null = null;
  groundOverlay: THREE.Mesh | null = null;
  grid: THREE.GridHelper | null = null;
  _groundSettings: GroundSettings | null = null;
  pmremGenerator: THREE.PMREMGenerator;
  _animationId: number = 0;
  _clock = new THREE.Clock();
  _onFrame: ((delta: number) => void) | null = null;
  _turntableActive = false;
  _turntableSpeed = 1.0;
  /** CubeCamera for real-time PBR floor reflections */
  _floorCubeCamera: THREE.CubeCamera | null = null;
  _floorCubeRT: THREE.WebGLCubeRenderTarget | null = null;
  _floorMaterial: THREE.MeshStandardMaterial | null = null;

  constructor() {
    this.scene = new THREE.Scene();
    // Limbo background: a vertical fade with a soft radial hotspot behind the
    // subject. This is the standard automotive studio backdrop - a flat colour
    // makes a dark car read as a silhouette with no separation from the void.
    this.scene.background = createLimboBackground();

    this.camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000);
    this.camera.position.set(5, 3, 5);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.minDistance = 1;
    this.controls.maxDistance = 50;
    this.controls.maxPolarAngle = Math.PI * 0.85;
    this.controls.target.set(0, 0.5, 0);
    this.controls.update();

    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.pmremGenerator.compileEquirectangularShader();

    // Ambient light
    const ambient = new THREE.AmbientLight(0x404060, 0.15);
    this.scene.add(ambient);
  }

  attach(container: HTMLElement): void {
    this.container = container;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';

    // Ground plane (placeholder â€” will be replaced by updateGround)
    this.ground = null;
    this.groundOverlay = null;
    this._floorCubeCamera = null;
    this._floorCubeRT = null;
    this._floorMaterial = null;

    this.setGrid(true);
    this.resize();
  }

  detach(): void {
    if (this.container && this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
    this.container = null;
  }

  resize(): void {
    if (!this.container) return;
    const w = Math.max(2, this.container.clientWidth);
    const h = Math.max(2, this.container.clientHeight);
    if (w === 0 || h === 0) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  getContainerSize(): { width: number; height: number } {
    if (!this.container) return { width: 0, height: 0 };
    const dpr = this.renderer.getPixelRatio();
    return {
      width: Math.round(this.container.clientWidth * dpr),
      height: Math.round(this.container.clientHeight * dpr),
    };
  }

  /** Remove existing ground objects from the scene and dispose their resources. */
  private _disposeGround(): void {
    if (this.groundOverlay) {
      this.scene.remove(this.groundOverlay);
      this.groundOverlay.geometry.dispose();
      (this.groundOverlay.material as THREE.Material).dispose();
      this.groundOverlay = null;
    }
    if (this.ground) {
      this.scene.remove(this.ground);
      this.ground.geometry.dispose();
      if (Array.isArray(this.ground.material)) {
        this.ground.material.forEach((m) => m.dispose());
      } else {
        this.ground.material.dispose();
      }
      this.ground = null;
    }
    if (this._floorCubeCamera) {
      if (this._floorCubeCamera && typeof this._floorCubeCamera.dispose === 'function') {
  this._floorCubeCamera.dispose();
}
      this._floorCubeCamera = null;
    }
    if (this._floorCubeRT) {
      this._floorCubeRT.dispose();
      this._floorCubeRT = null;
    }
    this._floorMaterial = null;
  }

  /**
   * Rebuild the ground plane according to the given settings.
   * Always uses MeshStandardMaterial (PBR) so roughness/metalness work correctly.
   * - reflections=true  â†’ CubeCamera real-time reflections via envMap
   * - reflections=false â†’ Scene environment only (or none)
   */
  updateGround(settings?: GroundSettings | null): void {
    if (!settings) return;
    // Merge with defaults so old scene files missing new fields don't crash
    const merged: GroundSettings = {
      visible: true,
      reflections: true,
      reflectionSharpness: 0.85,
      color: '#111118',
      roughness: 0.15,
      metalness: 0.95,
      fadeRadius: 8.0,
      ...settings,
    };
    this._groundSettings = merged;
    this._disposeGround();

    if (!merged.visible) return;

    const GROUND_SIZE = merged.size ?? 40;
    const groundGeo = new THREE.PlaneGeometry(GROUND_SIZE, GROUND_SIZE);
    const color = new THREE.Color(merged.color);

    // â”€â”€ PBR ground material (always MeshStandardMaterial) â”€â”€
    const groundMat = new THREE.MeshStandardMaterial({
      color: color.getHex(),
      metalness: merged.metalness,
      roughness: merged.roughness,
      envMapIntensity: 1.0,
      side: THREE.FrontSide,
    });
    this._floorMaterial = groundMat;

    if (merged.reflections) {
      // â”€â”€ CubeCamera for real-time planar reflections â”€â”€
      try {
        const dpr = Math.min(window.devicePixelRatio, 2);
        const cubeRTSize = Math.max(128, Math.round(512 * dpr));

        this._floorCubeRT = new THREE.WebGLCubeRenderTarget(cubeRTSize, {
          generateMipmaps: true,
          minFilter: THREE.LinearMipmapLinearFilter,
          magFilter: THREE.LinearFilter,
        });

        this._floorCubeCamera = new THREE.CubeCamera(0.1, 100, this._floorCubeRT);
        this._floorCubeCamera.position.set(0, 0.01, 0); // slightly above floor
        this._floorCubeCamera.userData.isProxy = true; // hide from SceneHierarchy
        this.scene.add(this._floorCubeCamera);

        // Use CubeCamera texture as envMap; roughness controls blur via mip levels
        groundMat.envMap = this._floorCubeRT.texture;
        groundMat.envMapIntensity = merged.reflectionSharpness;
      } catch (e) {
        console.warn('[LightForge] CubeCamera creation failed, falling back to env-only reflections:', e);
        this._floorCubeCamera = null;
        if (this._floorCubeRT) { this._floorCubeRT.dispose(); this._floorCubeRT = null; }
        if (this.scene.environment) {
          groundMat.envMap = this.scene.environment;
        }
        groundMat.envMapIntensity = 0.5;
      }
    } else {
      // No real-time reflections â€” use scene environment map if available
      if (this.scene.environment) {
        groundMat.envMap = this.scene.environment;
      }
      groundMat.envMapIntensity = 0.5;
    }

    this.ground = new THREE.Mesh(groundGeo, groundMat);

    // Base orientation: -90deg on X lays the plane flat. User rotation is
    // applied ON TOP of that, so 0/0/0 means "horizontal", not "vertical".
    const gPos = merged.position ?? { x: 0, y: 0, z: 0 };
    const gRot = merged.rotation ?? { x: 0, y: 0, z: 0 };
    const D2R = Math.PI / 180;

    this.ground.rotation.set(
      -Math.PI / 2 + gRot.x * D2R,
      gRot.y * D2R,
      gRot.z * D2R,
    );
    this.ground.position.set(gPos.x, gPos.y - 0.005, gPos.z);
    this.ground.receiveShadow = true;
    this.ground.name = '__floor__';
    this.scene.add(this.ground);

    // â”€â”€ Fade overlay: fades ground edges into background â”€â”€
    if (merged.fadeRadius > 0) {
      const overlayGeo = new THREE.PlaneGeometry(GROUND_SIZE, GROUND_SIZE);
      const overlayMat = new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        uniforms: {
          uFadeRadius: { value: merged.fadeRadius },
          uGroundSize: { value: GROUND_SIZE / 2 },
          uBgColor: { value: new THREE.Color('#0d0d1a') },
        },
        vertexShader: /* glsl */ `
          varying vec2 vWorldPos;
          void main() {
            vec4 worldPos = modelMatrix * vec4(position, 1.0);
            vWorldPos = worldPos.xz;
            gl_Position = projectionMatrix * viewMatrix * worldPos;
          }
        `,
        fragmentShader: /* glsl */ `
          uniform float uFadeRadius;
          uniform float uGroundSize;
          uniform vec3 uBgColor;
          varying vec2 vWorldPos;
          void main() {
            float dist = length(vWorldPos);
            float fade = 1.0 - smoothstep(uFadeRadius, uGroundSize, dist);
            gl_FragColor = vec4(uBgColor, 1.0 - fade);
          }
        `,
      });
      this.groundOverlay = new THREE.Mesh(overlayGeo, overlayMat);
      this.groundOverlay.rotation.x = -Math.PI / 2;
      this.groundOverlay.position.y = -0.003;
      this.groundOverlay.userData.isProxy = true; // hide from SceneHierarchy
      this.scene.add(this.groundOverlay);
    }
  }

  setGrid(visible: boolean): void {
    if (visible && !this.grid) {
      this.grid = new THREE.GridHelper(20, 40, 0x444466, 0x2a2a44);
      this.grid.position.y = 0.005;
      this.grid.userData.isGrid = true; // hide from SceneHierarchy
      this.scene.add(this.grid);
    } else if (!visible && this.grid) {
      this.scene.remove(this.grid);
      this.grid.geometry.dispose();
      (this.grid.material as THREE.Material).dispose();
      this.grid = null;
    }
    if (this.grid) this.grid.visible = visible;
  }

  setBackground(color: string, show: boolean): void {
    if (show) {
      this.scene.background = new THREE.Color(color);
    } else {
      // Fall back to the limbo backdrop, not a flat colour. A dark car against
      // flat #0d0d1a is a silhouette in a void - the gradient gives it something
      // to separate against.
      this.scene.background = createLimboBackground();
    }
  }

  setTurntable(active: boolean, speed: number): void {
    this._turntableActive = active;
    this._turntableSpeed = speed;
  }

  animateCameraTo(
    position: [number, number, number],
    target: [number, number, number],
    duration: number = 600
  ): void {
    const startPos = this.camera.position.clone();
    const startTarget = this.controls.target.clone();
    const endPos = new THREE.Vector3(...position);
    const endTarget = new THREE.Vector3(...target);
    const startTime = performance.now();

    const animate = () => {
      const elapsed = performance.now() - startTime;
      const t = Math.min(elapsed / duration, 1);
      const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

      this.camera.position.lerpVectors(startPos, endPos, ease);
      this.controls.target.lerpVectors(startTarget, endTarget, ease);
      this.controls.update();

      if (t < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }

  setOnFrame(cb: (delta: number) => void): void {
    this._onFrame = cb;
  }

  startRenderLoop(): void {
    const loop = () => {
      this._animationId = requestAnimationFrame(loop);
      const delta = this._clock.getDelta();

      // Turntable rotation
      if (this._turntableActive) {
        const model = this._findModel();
        if (model) {
          model.rotation.y += delta * this._turntableSpeed * 0.5;
        }
      }

      // Update CubeCamera for PBR floor reflections (hide floor to avoid self-reflection)
      if (this._floorCubeCamera && this.ground && this._groundSettings?.reflections) {
        this.ground.visible = false;
        this._floorCubeCamera.update(this.renderer, this.scene);
        this.ground.visible = true;
      }

      if (this._onFrame) this._onFrame(delta);
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
    };
    loop();
  }

  _findModel(): THREE.Object3D | null {
    for (const child of this.scene.children) {
      if (
        child.type === 'Group' &&
        !(child instanceof THREE.GridHelper) &&
        !child.userData.isHelper &&
        child !== this.ground &&
        child !== this._floorCubeCamera
      ) {
        return child;
      }
    }
    return null;
  }

  stopRenderLoop(): void {
    cancelAnimationFrame(this._animationId);
  }

  getCameraState(): { position: [number, number, number]; target: [number, number, number]; fov: number } {
    const target = this.controls.target;
    return {
      position: [
        this.camera.position.x,
        this.camera.position.y,
        this.camera.position.z,
      ] as [number, number, number],
      target: [target.x, target.y, target.z] as [number, number, number],
      fov: this.camera.fov,
    };
  }

  setCameraState(position: [number, number, number], target: [number, number, number], fov?: number): void {
    this.camera.position.set(...position);
    this.controls.target.set(...target);
    this.controls.update();
    if (fov !== undefined) {
      this.camera.fov = fov;
      this.camera.updateProjectionMatrix();
    }
  }

  takeScreenshot(): string {
    this.renderer.render(this.scene, this.camera);
    return this.renderer.domElement.toDataURL('image/png');
  }

  dispose(): void {
    this.stopRenderLoop();
    this.detach();
    this._disposeGround(); // properly clean up CubeCamera + render targets
    this.pmremGenerator.dispose();
    this.scene.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) {
          obj.material.forEach((m) => m.dispose());
        } else {
          obj.material.dispose();
        }
      }
    });
    this.controls.dispose();
    this.renderer.dispose();
  }
}

// â”€â”€ Vignette shader (custom) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const VignetteShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    intensity: { value: 0.4 },
    offset: { value: 1.1 },
    darkness: { value: 1.2 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float intensity;
    uniform float offset;
    uniform float darkness;
    varying vec2 vUv;
    void main() {
      vec4 texel = texture2D(tDiffuse, vUv);
      vec2 uv = (vUv - vec2(0.5)) * vec2(offset);
      float vig = clamp(1.0 - dot(uv, uv), 0.0, 1.0);
      float f = mix(1.0, vig, intensity * darkness);
      gl_FragColor = vec4(texel.rgb * f, texel.a);
    }
  `,
};

// â”€â”€ Color Grading shader (brightness / contrast / saturation) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const ColorGradingShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    brightness: { value: 0.0 },
    contrast: { value: 0.0 },
    saturation: { value: 0.0 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float brightness;
    uniform float contrast;
    uniform float saturation;
    varying vec2 vUv;

    void main() {
      vec4 texel = texture2D(tDiffuse, vUv);
      vec3 c = texel.rgb;

      // Brightness
      c += brightness * 0.5;

      // Contrast
      c = (c - 0.5) * (1.0 + contrast) + 0.5;

      // Saturation
      float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
      c = mix(vec3(lum), c, 1.0 + saturation);

      gl_FragColor = vec4(clamp(c, 0.0, 1.0), texel.a);
    }
  `,
};

// â”€â”€ Pipeline settings interface â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export interface PipelineConfig {
  bloom: { enabled: boolean; intensity: number; threshold: number; radius: number };
  ao: { enabled: boolean; radius: number; intensity: number };
  vignette: { enabled: boolean; intensity: number };
  colorGrading: { enabled: boolean; brightness: number; contrast: number; saturation: number };
  antialiasing: 'none' | 'fxaa' | 'smaa' | 'taa';
  shadowQuality: 'none' | 'low' | 'medium' | 'high';
  quality: 'low' | 'medium' | 'high' | 'ultra';
  tonemapping: 'aces' | 'reinhard' | 'linear';
  exposure: number;
}

export class RenderPipeline {
  private _sm: SceneManager;
  private _composer: EffectComposer | null = null;
  private _renderPass: RenderPass | null = null;
  private _bloomPass: UnrealBloomPass | null = null;
  private _smaaPass: SMAAPass | null = null;
  private _fxaaPass: ShaderPass | null = null;
  private _ssaoPass: SSAOPass | null = null;
  private _vignettePass: ShaderPass | null = null;
  private _colorGradingPass: ShaderPass | null = null;
  private _config: PipelineConfig;
  private _needsRebuild = false;

  constructor(sceneManager: SceneManager) {
    this._sm = sceneManager;
    this._config = {
      bloom: { enabled: true, intensity: 0.3, threshold: 0.8, radius: 0.5 },
      ao: { enabled: false, radius: 0.5, intensity: 0.5 },
      vignette: { enabled: false, intensity: 0.4 },
      colorGrading: { enabled: false, brightness: 0, contrast: 0, saturation: 0 },
      antialiasing: 'smaa',
      shadowQuality: 'high',
      quality: 'high',
      tonemapping: 'aces',
      exposure: 1.0,
    };
  }

  /** Build (or rebuild) the EffectComposer from scratch. */
  build(): void {
    this.dispose();
    const r = this._sm.renderer;
    const w = r.domElement.width || r.getSize(new THREE.Vector2()).x || 2;
    const h = r.domElement.height || r.getSize(new THREE.Vector2()).y || 2;

    this._composer = new EffectComposer(r);
    this._renderPass = new RenderPass(this._sm.scene, this._sm.camera);
    this._composer.addPass(this._renderPass);

    // Bloom
    if (this._config.bloom.enabled) {
      this._bloomPass = new UnrealBloomPass(
        new THREE.Vector2(w / 2, h / 2),
        this._config.bloom.intensity,
        this._config.bloom.radius,
        this._config.bloom.threshold,
      );
      this._composer.addPass(this._bloomPass);
    }

    // Anti-aliasing
    if (this._config.antialiasing === 'smaa') {
      // @ts-expect-error â€” SMAAPass types are incomplete in @types/three
      this._smaaPass = new SMAAPass(w, h);
      this._composer.addPass(this._smaaPass);
    } else if (this._config.antialiasing === 'fxaa') {
      const fxaaMat = new THREE.ShaderMaterial({ ...FXAAShader, uniforms: { ...FXAAShader.uniforms, resolution: { value: new THREE.Vector2(1 / w, 1 / h) } } });
      this._fxaaPass = new ShaderPass(fxaaMat);
      this._composer.addPass(this._fxaaPass);
    }
    // 'taa' â€” handled via renderer settings + jitter; we keep SMAA as fallback
    // 'none' â€” no AA pass

    // SSAO
    if (this._config.ao.enabled) {
      this._ssaoPass = new SSAOPass(
        this._sm.scene,
        this._sm.camera,
        w,
        h,
      );
      this._applyAOParams(this._config.ao.radius, this._config.ao.intensity);
      this._ssaoPass.output = SSAOPass.OUTPUT.Default;
      this._composer.addPass(this._ssaoPass);
    }

    // Vignette
    if (this._config.vignette.enabled) {
      const vMat = new THREE.ShaderMaterial(VignetteShader);
      vMat.uniforms['intensity'].value = this._config.vignette.intensity;
      this._vignettePass = new ShaderPass(vMat);
      this._composer.addPass(this._vignettePass);
    }

    // Color grading
    if (this._config.colorGrading.enabled) {
      const cgMat = new THREE.ShaderMaterial(ColorGradingShader);
      cgMat.uniforms['brightness'].value = this._config.colorGrading.brightness;
      cgMat.uniforms['contrast'].value = this._config.colorGrading.contrast;
      cgMat.uniforms['saturation'].value = this._config.colorGrading.saturation;
      this._colorGradingPass = new ShaderPass(cgMat);
      this._composer.addPass(this._colorGradingPass);
    }

    // Apply tone mapping & exposure to the renderer
    this._applyToneMapping(this._config.tonemapping);
    this._sm.renderer.toneMappingExposure = this._config.exposure;

    // Shadow quality
    this._applyShadowQuality(this._config.shadowQuality);
  }

  /** Render one frame through the composer (or fallback direct render). */
  render(): void {
    if (this._composer) {
      this._composer.render();
    } else {
      this._sm.renderer.render(this._sm.scene, this._sm.camera);
    }
  }

  /** Resize the composer and internal passes. */
  resize(): void {
    if (!this._composer) return;
    const r = this._sm.renderer;
    const size = r.getSize(new THREE.Vector2());
    const w = size.x || 2;
    const h = size.y || 2;
    this._composer.setSize(w, h);

    if (this._bloomPass) {
      this._bloomPass.resolution.set(w / 2, h / 2);
    }
    if (this._ssaoPass) {
      this._ssaoPass.setSize(w, h);
    }
    if (this._smaaPass) {
      this._smaaPass.setSize(w, h);
    }
    if (this._fxaaPass) {
      const mat = this._fxaaPass.material as THREE.ShaderMaterial;
      const res = mat.uniforms['resolution'];
      if (res && res.value instanceof THREE.Vector2) {
        res.value.set(1 / w, 1 / h);
      }
    }
  }

  /** Update the full pipeline config. Rebuilds composer if structural changes detected. */
  updateConfig(cfg: Partial<PipelineConfig>): void {
    const prev = { ...this._config };
    this._config = { ...this._config, ...cfg };

    const structuralChange =
      cfg.bloom?.enabled !== undefined && cfg.bloom.enabled !== prev.bloom.enabled ||
      cfg.antialiasing !== undefined && cfg.antialiasing !== prev.antialiasing ||
      cfg.vignette?.enabled !== undefined && cfg.vignette.enabled !== prev.vignette.enabled ||
      cfg.ao?.enabled !== undefined && cfg.ao.enabled !== prev.ao.enabled ||
      cfg.colorGrading?.enabled !== undefined && cfg.colorGrading.enabled !== prev.colorGrading.enabled;

    if (structuralChange) {
      this.build();
      return;
    }

    // In-place parameter updates (no rebuild needed)
    if (this._bloomPass && cfg.bloom) {
      this._bloomPass.strength = cfg.bloom.intensity ?? this._bloomPass.strength;
      this._bloomPass.radius = cfg.bloom.radius ?? this._bloomPass.radius;
      this._bloomPass.threshold = cfg.bloom.threshold ?? this._bloomPass.threshold;
    }

    if (this._ssaoPass && cfg.ao) {
      this._applyAOParams(
        cfg.ao.radius ?? this._config.ao.radius,
        cfg.ao.intensity ?? this._config.ao.intensity,
      );
    }

    if (this._vignettePass && cfg.vignette) {
      const mat = this._vignettePass.material as THREE.ShaderMaterial;
      mat.uniforms['intensity'].value = cfg.vignette.intensity ?? 0.4;
    }

    if (this._colorGradingPass && cfg.colorGrading) {
      const mat = this._colorGradingPass.material as THREE.ShaderMaterial;
      if (cfg.colorGrading.brightness !== undefined) mat.uniforms['brightness'].value = cfg.colorGrading.brightness;
      if (cfg.colorGrading.contrast !== undefined) mat.uniforms['contrast'].value = cfg.colorGrading.contrast;
      if (cfg.colorGrading.saturation !== undefined) mat.uniforms['saturation'].value = cfg.colorGrading.saturation;
    }

    if (cfg.tonemapping !== undefined) {
      this._applyToneMapping(cfg.tonemapping);
    }
    if (cfg.exposure !== undefined) {
      this._sm.renderer.toneMappingExposure = cfg.exposure;
    }
    if (cfg.shadowQuality !== undefined) {
      this._applyShadowQuality(cfg.shadowQuality);
    }
    if (cfg.quality !== undefined) {
      this._applyQuality(cfg.quality);
    }
  }

  // â”€â”€ Convenience setters (called from Viewport sync) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

  setEngine(engine: 'pbr' | 'pathtracer'): void {
    if (engine === 'pbr') {
      this._applyToneMapping(this._config.tonemapping);
    } else {
      this._sm.renderer.toneMapping = THREE.NoToneMapping;
    }
  }

  setToneMapping(mapping: 'aces' | 'reinhard' | 'linear'): void {
    this._config.tonemapping = mapping;
    this._applyToneMapping(mapping);
  }

  setBloom(enabled: boolean, intensity: number, threshold: number, radius: number): void {
    this.updateConfig({
      bloom: { enabled, intensity, threshold, radius },
    });
  }

  setAO(enabled: boolean, radius: number, intensity: number): void {
    this.updateConfig({
      ao: { enabled, radius, intensity },
    });
  }

  setAntialiasing(mode: 'none' | 'fxaa' | 'smaa' | 'taa'): void {
    this.updateConfig({ antialiasing: mode });
  }

  setShadowQuality(quality: 'none' | 'low' | 'medium' | 'high'): void {
    this._config.shadowQuality = quality;
    this._applyShadowQuality(quality);
  }

  setQuality(quality: 'low' | 'medium' | 'high' | 'ultra'): void {
    this._config.quality = quality;
    this._applyQuality(quality);
  }

  setExposure(exposure: number): void {
    this._config.exposure = exposure;
    this._sm.renderer.toneMappingExposure = exposure;
  }

  setVignette(enabled: boolean, intensity: number): void {
    this.updateConfig({ vignette: { enabled, intensity } });
  }

  setColorGrading(enabled: boolean, brightness: number, contrast: number, saturation: number): void {
    this.updateConfig({ colorGrading: { enabled, brightness, contrast, saturation } });
  }

  /** Get the EffectComposer (for screenshot / export via composer). */
  getComposer(): EffectComposer | null {
    return this._composer;
  }

  /** Take a screenshot â€” renders one frame and returns a data URL. */
  capture(): string {
    this.render();
    return this._sm.renderer.domElement.toDataURL('image/png');
  }

  /** Dispose all passes and the composer. */
  dispose(): void {
    if (this._composer) {
      const passes = this._composer.passes.slice().reverse();
      for (const pass of passes) {
        if ('dispose' in pass && typeof (pass as { dispose: () => void }).dispose === 'function') {
          (pass as { dispose: () => void }).dispose();
        }
      }
      this._composer.dispose();
    }
    this._composer = null;
    this._renderPass = null;
    this._bloomPass = null;
    this._ssaoPass = null;
    this._smaaPass = null;
    this._fxaaPass = null;
    this._vignettePass = null;
    this._colorGradingPass = null;
  }

  // â”€â”€ Private helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

  /** Apply SSAO parameters â€” radius controls kernel spread, intensity controls maxDistance scaling. */
  private _applyAOParams(radius: number, intensity: number): void {
    if (!this._ssaoPass) return;
    this._ssaoPass.kernelRadius = radius;
    this._ssaoPass.minDistance = 0.005;
    // Scale maxDistance with intensity: higher intensity â†’ AO visible at greater depth range
    // Tuned for car-scale scenes (objects ~2â€“5m across)
    this._ssaoPass.maxDistance = 0.05 + intensity * 0.5;
  }

  private _applyToneMapping(mapping: 'aces' | 'reinhard' | 'linear'): void {
    const r = this._sm.renderer;
    switch (mapping) {
      case 'aces':
        r.toneMapping = THREE.ACESFilmicToneMapping;
        break;
      case 'reinhard':
        r.toneMapping = THREE.ReinhardToneMapping;
        break;
      case 'linear':
        r.toneMapping = THREE.LinearToneMapping;
        break;
    }
    r.toneMappingExposure = this._config.exposure;
  }

  private _applyShadowQuality(quality: string): void {
    const r = this._sm.renderer;
    switch (quality) {
      case 'none':
        r.shadowMap.enabled = false;
        break;
      case 'low':
        r.shadowMap.enabled = true;
        r.shadowMap.type = THREE.BasicShadowMap;
        break;
      case 'medium':
        r.shadowMap.enabled = true;
        r.shadowMap.type = THREE.PCFShadowMap;
        break;
      case 'high':
      default:
        r.shadowMap.enabled = true;
        r.shadowMap.type = THREE.PCFSoftShadowMap;
        break;
    }

    // Update shadow map sizes on all lights
    this._sm.scene.traverse((child) => {
      const light = child as THREE.DirectionalLight | THREE.SpotLight | THREE.PointLight;
      if (light.isLight && light.shadow) {
        const shadow = light.shadow;
        switch (quality) {
          case 'low':
            shadow.mapSize.set(512, 512);
            break;
          case 'medium':
            shadow.mapSize.set(1024, 1024);
            break;
          case 'high':
          default:
            shadow.mapSize.set(2048, 2048);
            break;
        }
        if (shadow.map) {
          shadow.map.dispose();
          shadow.map = null;
        }
      }
    });
  }

  private _applyQuality(quality: 'low' | 'medium' | 'high' | 'ultra'): void {
    const r = this._sm.renderer;
    switch (quality) {
      case 'low':
        r.setPixelRatio(1);
        break;
      case 'medium':
        r.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
        break;
      case 'high':
        r.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        break;
      case 'ultra':
        r.setPixelRatio(window.devicePixelRatio);
        break;
    }
    this._sm.resize();
    if (this._composer) {
      this.resize();
    }
  }
}

interface LightSyncEntry {
  id: string;
  type: string;
  color: string;
  brightness: number;
  opacity: number;
  visible: boolean;
  solo: boolean;
  falloff: string;
  gearVisible: boolean;
  transform: {
    position: { x: number; y: number; z: number };
    spherical: { lat: number; lng: number; radius: number; height: number };
    rotation: { x: number; y: number; z: number; enabled: boolean };
  };
  // Spotlight-specific
  spotAngle?: number;
  spotPenumbra?: number;
  spotDecay?: number;
  // Area light specific
  areaWidth?: number;
  areaHeight?: number;
}

interface LightObjectEntry {
  object: THREE.Object3D;
  lightType: string;
  target?: THREE.Object3D;
}

export class LightManager {
  private _scene: THREE.Scene;
  private _entries: Map<string, LightObjectEntry> = new Map();
  private _helpers: Map<string, THREE.Object3D> = new Map();
  private _types: Map<string, string> = new Map();

  constructor(scene: THREE.Scene) {
    this._scene = scene;
    ensureRectAreaLib();
  }

  syncLights(lights: LightSyncEntry[]): void {
    const activeIds = new Set(lights.map((l) => l.id));
    const hasSolo = lights.some((l) => l.solo);

    // Remove stale lights
    for (const [id] of this._entries) {
      if (!activeIds.has(id)) {
        this._removeLight(id);
      }
    }

    // Create or update each light
    for (const ld of lights) {
      const isEffectiveSolo = hasSolo ? ld.solo : true;
      const shouldShow = ld.visible && isEffectiveSolo;

      const existing = this._entries.get(ld.id);
      const currentType = this._types.get(ld.id);

      // If type changed, recreate the light
      if (existing && currentType !== ld.type) {
        this._removeLight(ld.id);
      }

      if (!this._entries.has(ld.id)) {
        this._createLight(ld);
      }

      this._updateLight(ld, shouldShow);
    }
  }

  private _createLight(ld: LightSyncEntry): void {
    ensureRectAreaLib();
    const lightObj = this._createLightByType(ld.type);

    // For spot/directional, add a target object
    let target: THREE.Object3D | undefined;
    if (lightObj instanceof THREE.SpotLight || lightObj instanceof THREE.DirectionalLight) {
      target = new THREE.Object3D();
      target.position.set(0, 0, 0);
      this._scene.add(target);
      lightObj.target = target;
    }

    this._scene.add(lightObj);
    this._entries.set(ld.id, { object: lightObj, lightType: ld.type, target });
    this._types.set(ld.id, ld.type);

    // Create helper
    // Stamp the store id onto the THREE object so the gizmo can find this
    // light without reaching into LightManager internals.
    lightObj.userData.lightId = ld.id;

    const helper = this._createHelper(ld.type, lightObj as THREE.Light, ld);
    if (helper) {
      this._helpers.set(ld.id, helper);
      this._scene.add(helper);
    }
  }

  private _updateLight(ld: LightSyncEntry, shouldShow: boolean): void {
    const entry = this._entries.get(ld.id);
    if (!entry) return;

    const { object: lightObj } = entry;

    // Compute position from spherical
    const s = ld.transform.spherical;
    const latRad = (s.lat * Math.PI) / 180;
    const lngRad = (s.lng * Math.PI) / 180;
    // cartesianToSpherical() stores `radius` as the HORIZONTAL distance
    // (sqrt(x^2+z^2)) and `height` as y. Multiplying by cos(lat) here applies
    // the elevation a second time, so every round-trip through the store pulls
    // the light in toward the origin - which is why LightPaint never landed
    // where you clicked.
    void latRad;
    const px = s.radius * Math.cos(lngRad);
    const py = s.height;
    const pz = s.radius * Math.sin(lngRad);

    lightObj.position.set(px, py, pz);
    lightObj.visible = shouldShow;

    // Apply rotation if enabled
    if (ld.transform.rotation.enabled) {
      lightObj.rotation.set(
        (ld.transform.rotation.x * Math.PI) / 180,
        (ld.transform.rotation.y * Math.PI) / 180,
        (ld.transform.rotation.z * Math.PI) / 180,
      );
    }

    if (lightObj instanceof THREE.Light) {
      lightObj.color.set(ld.color);
      // Map brightness 0-1000 to intensity 0-10
      lightObj.intensity = (ld.brightness / 1000) * 10;

      // Apply opacity (only meaningful via distance/decay for physically-based)
      // We scale intensity by opacity/100 to simulate dimming
      if (ld.opacity < 100) {
        lightObj.intensity *= ld.opacity / 100;
      }

      // Falloff
      if (lightObj instanceof THREE.PointLight || lightObj instanceof THREE.SpotLight) {
        switch (ld.falloff) {
          case 'linear':
            lightObj.decay = 1;
            break;
          case 'none':
            lightObj.decay = 0;
            break;
          case 'custom':
            lightObj.decay = 1.5;
            break;
          case 'quadratic':
          default:
            lightObj.decay = 2;
            break;
        }
      }

      // Spotlight-specific
      if (lightObj instanceof THREE.SpotLight) {
        if (ld.spotAngle !== undefined) {
          lightObj.angle = (ld.spotAngle * Math.PI) / 180;
        }
        if (ld.spotPenumbra !== undefined) {
          lightObj.penumbra = ld.spotPenumbra;
        }
        if (ld.spotDecay !== undefined) {
          lightObj.decay = ld.spotDecay;
        }
      }

      // Area light dimensions
      if (lightObj instanceof THREE.RectAreaLight) {
        if (ld.areaWidth !== undefined) lightObj.width = ld.areaWidth;
        if (ld.areaHeight !== undefined) lightObj.height = ld.areaHeight;
      }

      // Shadow config
      this._configureShadows(lightObj, ld.type);
    }

    // Update target to look at origin for spot/directional
    if (entry.target) {
      entry.target.position.set(0, 0, 0);
    }

    // Update helper
    const helper = this._helpers.get(ld.id);
    if (helper) {
      helper.visible = shouldShow && ld.gearVisible;
      helper.position.copy(lightObj.position);
      helper.rotation.copy(lightObj.rotation);
      if (helper instanceof THREE.Mesh && lightObj instanceof THREE.Light) {
        (helper.material as THREE.MeshBasicMaterial).color.copy(lightObj.color);

        // Rebuild the plane when the area dimensions change. BufferGeometry is
        // immutable, so mutating PlaneGeometry.parameters does nothing - the old
        // geometry must be disposed and replaced.
        const isAreaType = ld.type === 'area' || ld.type === 'overhead';
        if (isAreaType) {
          const w = Math.max(0.01, ld.areaWidth ?? 2);
          const h = Math.max(0.01, ld.areaHeight ?? 2);
          const prev = helper.userData as { hw?: number; hh?: number };
          if (prev.hw !== w || prev.hh !== h) {
            helper.geometry.dispose();
            helper.geometry = new THREE.PlaneGeometry(w, h);
            prev.hw = w;
            prev.hh = h;
          }
        }
      }
    }
  }

  private _createLightByType(type: string): THREE.Object3D {
    const color = 0xffffff;
    const intensity = 1;
    switch (type) {
      case 'directional': {
        const dl = new THREE.DirectionalLight(color, intensity);
        dl.castShadow = true;
        dl.shadow.mapSize.set(2048, 2048);
        dl.shadow.camera.near = 0.5;
        dl.shadow.camera.far = 50;
        dl.shadow.camera.left = -10;
        dl.shadow.camera.right = 10;
        dl.shadow.camera.top = 10;
        dl.shadow.camera.bottom = -10;
        dl.shadow.bias = -0.001;
        return dl;
      }
      case 'spot': {
        const sl = new THREE.SpotLight(color, intensity, 50, Math.PI / 4, 0.5, 2);
        sl.castShadow = true;
        sl.shadow.mapSize.set(2048, 2048);
        sl.shadow.bias = -0.001;
        return sl;
      }
      case 'area': {
        ensureRectAreaLib();
        return new THREE.RectAreaLight(color, intensity, 2, 2);
      }
      case 'overhead': {
        ensureRectAreaLib();
        return new THREE.RectAreaLight(color, intensity, 4, 4);
      }
      case 'rim': {
        const sl = new THREE.SpotLight(color, intensity, 50, Math.PI / 6, 0.3, 2);
        sl.castShadow = true;
        sl.shadow.mapSize.set(2048, 2048);
        sl.shadow.bias = -0.001;
        return sl;
      }
      case 'underlight': {
        const pl = new THREE.PointLight(color, intensity, 50, 2);
        pl.castShadow = true;
        pl.shadow.mapSize.set(1024, 1024);
        return pl;
      }
      case 'ies':
      case 'point':
      default: {
        const pl = new THREE.PointLight(color, intensity, 50, 2);
        pl.castShadow = true;
        pl.shadow.mapSize.set(1024, 1024);
        return pl;
      }
    }
  }

  private _configureShadows(light: THREE.Object3D, _type: string): void {
    const sl = light as THREE.SpotLight;
    const dl = light as THREE.DirectionalLight;
    const pl = light as THREE.PointLight;
    const shadowCapable = light instanceof THREE.SpotLight
      || light instanceof THREE.DirectionalLight
      || light instanceof THREE.PointLight;

    if (!shadowCapable || !sl.shadow) return;

    sl.castShadow = true;
    sl.shadow.bias = -0.001;

    if (light instanceof THREE.DirectionalLight) {
      dl.shadow.mapSize.set(2048, 2048);
      dl.shadow.camera.near = 0.5;
      dl.shadow.camera.far = 50;
      dl.shadow.camera.left = -10;
      dl.shadow.camera.right = 10;
      dl.shadow.camera.top = 10;
      dl.shadow.camera.bottom = -10;
    } else if (light instanceof THREE.SpotLight) {
      sl.shadow.mapSize.set(2048, 2048);
      sl.shadow.camera.near = 0.5;
      sl.shadow.camera.far = 50;
    } else if (light instanceof THREE.PointLight) {
      pl.shadow.mapSize.set(1024, 1024);
      pl.shadow.camera.near = 0.1;
      pl.shadow.camera.far = 50;
    }
  }

  private _createHelper(type: string, light: THREE.Light, ld?: { areaWidth?: number; areaHeight?: number }): THREE.Object3D | null {
    const isArea = type === 'area' || type === 'overhead';
    let geo: THREE.BufferGeometry;
    if (isArea) {
      const w = Math.max(0.01, ld?.areaWidth ?? 2);
      const h = Math.max(0.01, ld?.areaHeight ?? 2);
      geo = new THREE.PlaneGeometry(w, h);
    } else if (type === 'directional') {
      // Use a slightly larger sphere for directional
      geo = new THREE.SphereGeometry(0.1, 12, 12);
    } else {
      geo = new THREE.SphereGeometry(0.06, 10, 10);
    }
    const mat = new THREE.MeshBasicMaterial({
      color: light.color,
      transparent: true,
      opacity: 0.7,
      depthTest: false,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.userData.isHelper = true;
    mesh.renderOrder = 999;
    return mesh;
  }

  private _removeLight(id: string): void {
    const entry = this._entries.get(id);
    if (!entry) return;

    const { object, target } = entry;

    // Dispose shadow maps
    const shadowLight = object as THREE.SpotLight | THREE.DirectionalLight | THREE.PointLight;
    if (object instanceof THREE.Light && shadowLight.shadow && shadowLight.shadow.map) {
      shadowLight.shadow.map.dispose();
    }

    this._scene.remove(object);
    this._disposeObject(object);
    if (target) {
      this._scene.remove(target);
    }

    this._entries.delete(id);
    this._types.delete(id);

    const helper = this._helpers.get(id);
    if (helper) {
      this._scene.remove(helper);
      this._disposeObject(helper);
      this._helpers.delete(id);
    }
  }

  private _disposeObject(obj: THREE.Object3D): void {
    obj.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.geometry.dispose();
        if (child.material instanceof THREE.Material) {
          child.material.dispose();
        }
      }
    });
  }

  getLightObject(id: string): THREE.Object3D | undefined {
    return this._entries.get(id)?.object;
  }

  getLightCount(): number {
    return this._entries.size;
  }

  dispose(): void {
    const ids = Array.from(this._entries.keys());
    for (const id of ids) {
      this._removeLight(id);
    }
  }
}

export class ModelLoader {
  private _scene: THREE.Scene;
  private _currentModel: THREE.Group | null = null;
  private _loader = new GLTFLoader();
  private _loading = false;
  private _progress = 0;
  private _onProgress: ((progress: number) => void) | null = null;
  private _onLoaded: ((name: string) => void) | null = null;
  private _onError: ((error: string) => void) | null = null;

  constructor(scene: THREE.Scene) {
    this._scene = scene;
  }

  get loading(): boolean { return this._loading; }
  get progress(): number { return this._progress; }

  getCurrentModel(): THREE.Group | null {
    return this._currentModel;
  }

  setCallbacks(callbacks: {
    onProgress?: (progress: number) => void;
    onLoaded?: (name: string) => void;
    onError?: (error: string) => void;
  }): void {
    this._onProgress = callbacks.onProgress ?? null;
    this._onLoaded = callbacks.onLoaded ?? null;
    this._onError = callbacks.onError ?? null;
  }

  async loadFromFile(file: File): Promise<void> {
    if (this._loading) return;
    this._loading = true;
    this._progress = 0;
    this._onProgress?.(0);

    // Read file as ArrayBuffer to store raw data for scene persistence
    let arrayBuffer: ArrayBuffer | null = null;
    try {
      arrayBuffer = await file.arrayBuffer();
      setRawModelData(arrayBuffer, file.name);
    } catch {
      // Non-critical â€” model will load but won't be saveable
    }

    const url = URL.createObjectURL(file);

    try {
      const gltf = await new Promise<{ scene: THREE.Group }>((resolve, reject) => {
        this._loader.load(
          url,
          (result) => resolve(result),
          (event) => {
            if (event.lengthComputable) {
              this._progress = (event.loaded / event.total) * 100;
              this._onProgress?.(this._progress);
            }
          },
          (error) => reject(error)
        );
      });

      this.removeCurrentModel();

      this._currentModel = gltf.scene;
      this._scene.add(gltf.scene);

      // Enable shadows
      gltf.scene.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });

      // Center and scale
      const box = new THREE.Box3().setFromObject(gltf.scene);
      const center = box.getCenter(new THREE.Vector3());
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z);
      if (maxDim > 0) {
        const scale = 4 / maxDim;
        gltf.scene.scale.multiplyScalar(scale);
      }
      // Recompute after scaling
      const box2 = new THREE.Box3().setFromObject(gltf.scene);
      const center2 = box2.getCenter(new THREE.Vector3());
      gltf.scene.position.sub(center2);
      gltf.scene.position.y += box2.getSize(new THREE.Vector3()).y / 2;

      this._loading = false;
      this._progress = 100;
      this._onProgress?.(100);
      this._onLoaded?.(file.name.replace(/\.(glb|gltf)$/i, ''));
    } catch (err) {
      this._loading = false;
      this._progress = 0;
      const msg = err instanceof Error ? err.message : 'Failed to load model';
      this._onError?.(msg);
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  /**
   * Load a model from an ArrayBuffer (e.g., restored from a scene file).
   */
  async loadFromBuffer(arrayBuffer: ArrayBuffer, fileName: string): Promise<void> {
    if (this._loading) return;
    this._loading = true;
    this._progress = 0;
    this._onProgress?.(0);

    setRawModelData(arrayBuffer, fileName);

    const blob = new Blob([arrayBuffer], { type: 'model/gltf-binary' });
    const url = URL.createObjectURL(blob);

    try {
      const gltf = await new Promise<{ scene: THREE.Group }>((resolve, reject) => {
        this._loader.load(
          url,
          (result) => resolve(result),
          (event) => {
            if (event.lengthComputable) {
              this._progress = (event.loaded / event.total) * 100;
              this._onProgress?.(this._progress);
            }
          },
          (error) => reject(error)
        );
      });

      this.removeCurrentModel();

      this._currentModel = gltf.scene;
      this._scene.add(gltf.scene);

      // Enable shadows
      gltf.scene.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });

      // Center and scale
      const box = new THREE.Box3().setFromObject(gltf.scene);
      const center = box.getCenter(new THREE.Vector3());
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z);
      if (maxDim > 0) {
        const scale = 4 / maxDim;
        gltf.scene.scale.multiplyScalar(scale);
      }
      const box2 = new THREE.Box3().setFromObject(gltf.scene);
      const center2 = box2.getCenter(new THREE.Vector3());
      gltf.scene.position.sub(center2);
      gltf.scene.position.y += box2.getSize(new THREE.Vector3()).y / 2;

      this._loading = false;
      this._progress = 100;
      this._onProgress?.(100);
      this._onLoaded?.(fileName.replace(/\.(glb|gltf)$/i, ''));
    } catch (err) {
      this._loading = false;
      this._progress = 0;
      const msg = err instanceof Error ? err.message : 'Failed to load model from buffer';
      this._onError?.(msg);
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  removeCurrentModel(): void {
    if (this._currentModel) {
      this._scene.remove(this._currentModel);
      this._currentModel.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          if (Array.isArray(child.material)) {
            child.material.forEach((m) => m.dispose());
          } else {
            child.material.dispose();
          }
        }
      });
      this._currentModel = null;
      clearRawModelData();
    }
  }

  dispose(): void {
    this.removeCurrentModel();
  }
}

/**
 * Build the limbo backdrop as a 2D canvas texture.
 *
 * Two layers: a vertical dark-to-lighter fade (floor is brighter than sky, as in
 * a real cyc wall), plus a soft radial hotspot centred behind the subject. A flat
 * colour gives a dark car nothing to separate against.
 */
export function createLimboBackground(): THREE.Texture {
  const w = 1024;
  const h = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');

  if (!ctx) return new THREE.Texture();

  // Vertical fade - darkest at the top, lifting toward the horizon
  const vertical = ctx.createLinearGradient(0, 0, 0, h);
  vertical.addColorStop(0.0, '#08080f');
  vertical.addColorStop(0.55, '#14141f');
  vertical.addColorStop(1.0, '#1e1e2b');
  ctx.fillStyle = vertical;
  ctx.fillRect(0, 0, w, h);

  // Soft hotspot behind the subject
  const radial = ctx.createRadialGradient(w / 2, h * 0.55, 0, w / 2, h * 0.55, w * 0.5);
  radial.addColorStop(0.0, 'rgba(70, 70, 95, 0.55)');
  radial.addColorStop(0.5, 'rgba(40, 40, 60, 0.25)');
  radial.addColorStop(1.0, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = radial;
  ctx.fillRect(0, 0, w, h);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}